package ex02blk;

import java.util.Scanner;

public class Ex02BLK {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner (System.in);
        double Cel, Fah;
        
        System.out.println("Digite uma temperatura em Fahrenheit");
        Fah = teclado.nextFloat();
        
        Cel = (Fah - 32.0) * (5.0/9.0);
        
        System.out.println("A temperatura em Celsius é " + Cel);
                
    }
    
}
