package ex03blk;
import java.util.Scanner;
public class Ex03BLK {

    public static void main(String[] args) {
    
        Scanner teclado = new Scanner (System.in);
        double raio, volume, altura;
        
        System.out.println("Informe o valor do raio da lata em cm");
        raio = teclado.nextDouble();
        
        System.out.println("Agora informe o valor da altura em cm");
        altura = teclado.nextDouble();
        
        volume = 3.1416 * raio * raio * altura;
        
        System.out.println("O volume da lata e: " + volume + "cm cu1bicos");
    }

}
