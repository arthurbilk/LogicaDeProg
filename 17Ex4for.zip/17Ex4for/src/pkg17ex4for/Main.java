/*
4) Crie um programa com um vetor e uma matriz. No vetor armazene o nome de 6 alunos.
Na matriz armazene 3 notas para cada aluno. Após preenchidos, apresente uma listagem
com os nomes dos alunos, sua média e se o mesmo está aprovado ou reprovado
(considere 6 ou mais como a nota para ser aprovado).
 */
package pkg17ex4for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double acumNotas = 0;
        String vetNomes[] = new String[6];
        double matNotas[][] = new double[vetNomes.length][3];
        double vetMedias[] = new double[vetNomes.length];

        for (int linhas = 0; linhas < vetNomes.length; linhas++) {
            System.out.println("Informe o nome do aluno N" + (linhas + 1));
            vetNomes[linhas] = in.nextLine();

            acumNotas = 0;
            for (int colunas = 0; colunas < 3; colunas++) {
                System.out.println("Informe a nota " + (colunas + 1));
                matNotas[linhas][colunas] = in.nextDouble();
                in.nextLine();
                
                acumNotas += matNotas[linhas][colunas];
            }
            vetMedias[linhas] = acumNotas / 3;
        }
        
        for (int linhas = 0; linhas < vetNomes.length; linhas++) {
            System.out.println("============================");
            System.out.println("Aluno: " + vetNomes[linhas]);
            
            for (int colunas = 0; colunas < 3; colunas++) {
                System.out.println("     . Nota " + (colunas + 1) + ": " + matNotas[linhas][colunas]);
            }
            System.out.println("Media: " + vetMedias[linhas] + "/10.0");
            if (vetMedias[linhas] >= 6) {
                System.out.println("Status: APROVADO");
            } else {
                System.out.println("Status: REPROVADO");
            }
        }
    }

}
