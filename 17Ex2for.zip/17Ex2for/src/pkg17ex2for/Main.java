/*
2) Crie um programa com uma matriz 3x3 numérica, que é preenchida pelo usuário, e que
após preenchida, procure o menor elemento na matriz e o apresente na tela.
 */
package pkg17ex2for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int tamanho = 3, linhaMenor = 0, colunaMenor = 0;
        int matrizNum[][] = new int[tamanho][tamanho];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.println("Informe um valor para a posicao[" + linha + "][" + coluna + "]:");
                matrizNum[linha][coluna] = in.nextInt();
            }
        }
        
        int menor = matrizNum[0][0];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                if (matrizNum[linha][coluna] < menor) {
                    menor = matrizNum[linha][coluna];
                    linhaMenor = linha;
                    colunaMenor = coluna;
                }
            }
        }
        
        System.out.println("O menor numero eh " + menor);
        System.out.println("Linha: " + linhaMenor + ". Coluna: " + colunaMenor);
    }

}
