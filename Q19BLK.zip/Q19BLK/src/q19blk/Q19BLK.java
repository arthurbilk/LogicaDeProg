package q19blk;

import java.util.Scanner;

public class Q19BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        double a, b, c, area, p;

        System.out.println("Informe os 3 lados do triangulo em cm");
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if (a < b + c && b < a + c && c < b + a) {

            p = (a + b + c) / 2;
            area = Math.sqrt((p * (p - a) * (p - b) * (p - c)));

            System.out.println("A area do seu triangulo eh: " + area + "cm2");

        }

        System.out.println(a + ", " + b + ", " + c);
    }

}
