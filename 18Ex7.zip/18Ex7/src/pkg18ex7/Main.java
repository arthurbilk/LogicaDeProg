/*
7 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresenta esse nome com os nomes do meio abreviados.
Ex. Paulo Eduardo Marcondes Silva → Paulo E. M. Silva
 */
package pkg18ex7;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String nomeCompleto;
        int cont = 0;
        char nomeMeio = ' ';
        
        System.out.println("Informe seu nome completo:");
        nomeCompleto = in.nextLine();
        
        String[] vetNome = nomeCompleto.split(" ");
        String nome = vetNome[0];
        String sobrenome = vetNome[vetNome.length - 1];
        
        System.out.print(nome);
        for (int i = 1; i < vetNome.length - 1; i++) {
            nomeMeio = vetNome[i].charAt(0);
            System.out.print(" " + nomeMeio + ".");
        }
        System.out.print(" " + sobrenome);
    }
    
}
