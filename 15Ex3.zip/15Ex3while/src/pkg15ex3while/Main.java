
package pkg15ex3while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int quant = 9, divisor = 0, cont = 0, contDiv = 1;
        int num[] = new int[quant];
        int divisores[] = new int[quant];
        
        while (cont < quant) {            
            System.out.println("Informe o numero " + (cont + 1) + ":");
            num[cont] = in.nextInt();
            cont++;
        }
        
        cont = 0;
        
        while (cont < quant) {            
            while (contDiv <= num[cont]) {                
                if (num[cont] % contDiv == 0) {
                    divisor++; 
                }
                contDiv++;
            }
            divisores[cont] = divisor;
            divisor = 0;
            contDiv = 1;
            cont++;
        }
        
        cont = 0;
        
        while (cont < quant) {            
            if (divisores[cont] == 2) {
                System.out.println(num[cont] + " eh um  numero primo");
            } else {
                System.out.println(num[cont] + " nao eh um numero primo");
            }
            cont++;
        }
    }
    
}
