
package pkg15ex3for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int quant = 9, divisor = 0;
        int num[] = new int[quant];
        int divisores[] = new int[quant];
        
        for (int i = 0; i < quant; i++) {
            System.out.println("Informe o numero " + (i + 1) + ":");
            num[i] = in.nextInt();
        }
        
        for (int i = 0; i < quant; i++) {
            for (int j = 1; j <= num[i]; j++) {
                if (num[i] % j == 0) {
                    divisor++; 
                }
            }
            divisores[i] = divisor;
            divisor = 0;
        }
        
        for (int i = 0; i < quant; i++) {
            if (divisores[i] == 2) {
                System.out.println(num[i] + " eh um  numero primo");
            } else {
                System.out.println(num[i] + " nao eh um numero primo");
            }
        }
    }
    
}
