/*
3. Crie um programa com uma sub-rotina que receba um único valor 
representando segundos. Essa deverá convertê-lo em horas, minutos e segundos e 
apresentar o resultado na tela. O programa principal deve permitir testar a mesma.
 */
package pkg19ex3;

import java.util.Scanner;

public class Main {
    
    static void conversao (int a) {
        int horas = a / 3600;
        int b = a % 3600;
        int minutos = b / 60;
        b = b % 60;
        int s = b;
        
        System.out.println(a + "s equivalem a: " + horas + "h, " + minutos + "m e " + s + "s.");
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe um valor em segundos: ");
        int segundos = in.nextInt();
        
        conversao(segundos);
    }
    
}
