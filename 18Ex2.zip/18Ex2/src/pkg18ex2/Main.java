/*
2 - Crie um programa que informa a quantidade de vogais de uma frase informada pelo
usuário;
 */
package pkg18ex2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char vogais[] = {'a', 'e', 'i', 'o', 'u'};
        int contVogais = 0;
        
        System.out.println("Informe uma frase");
        String frase = in.nextLine().toLowerCase();
        
        for (int i = 0; i < vogais.length; i++) {
            for (int j = 0; j < frase.length(); j++) {
                if (frase.charAt(j) == vogais[i]) {
                    contVogais++;
                }
            }
        }
        
        System.out.println("A frase '" + frase + "' tem " + contVogais + " vogais");
    }
    
}
