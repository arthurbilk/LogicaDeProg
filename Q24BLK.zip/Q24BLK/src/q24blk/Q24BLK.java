package q24blk;
import java.util.Scanner;
public class Q24BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double valor, apple;
        
        System.out.println("Informe quantas maças voce comprou");
        apple = in.nextDouble();
        
        if (apple < 12) {
            valor = apple * 1.3;
        } else {
            valor = apple;
        }
        
        System.out.println("O valor da compra foi de: R$" + valor);
        
    }
    
}