/*
1e – Faça um programa onde o usuário deve digitar uma senha. Essa senha deve ser previamente
definida e estar fixa no código (contendo letras, números e símbolos). Quando o usuário acertar a
senha, informe. Utilize um laço de repetição do-while que fica pedindo a senha repetidamente.
 */
package pkg18ex1e;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String senha = "Josecarlos.88";
        String senhaUsuario;
        boolean acertou = false;
        int cont = 0;
        
        do {
            if (cont == 0) {
                System.out.print("Informe uma senha:");
            senhaUsuario = in.nextLine();
            } else {
                System.out.print("Digite novamente:");
                senhaUsuario = in.nextLine();
            }
            
            if (senha.equals(senhaUsuario)) {
                System.out.println("Voce acertou a senha!");
                acertou = true;
            } else {
                System.out.println("Voce errou a senha.");
            }
            
            cont++;
        } while (!acertou);
    }
    
}
