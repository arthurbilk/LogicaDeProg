/*
2e – Faça um programa onde o usuário deve digitar uma senha. Valide que essa senha contenha ao
menos 8 caracteres, um número, um caractere maiúsculo e um símbolo. Dica: veja tabela ASCII.
 */
package pkg18ex2e;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String senha;
        boolean valida, maiusculas, minusculas, cEspeciais, tamanho, numeros;
        int cont = 0;

        do {
            valida = false;
            maiusculas = false;
            minusculas = false;
            cEspeciais = false;
            tamanho = false;
            numeros = false;

            if (cont == 0) {
                System.out.println("Informe uma senha (deve conter letras maiusculas e minusculas, caracteres especiais, numeros e no minimo 8 caracteres):");
                senha = in.nextLine();
            } else {
                System.out.print("Senha invalida. Digite novamente:");
                senha = in.nextLine();
            }

            if (senha.length() >= 8) {
                tamanho = true;
            }

            for (int i = 0; i < senha.length(); i++) {
                char casa = senha.charAt(i);

                if (65 <= (int) casa && (int) casa <= 90) {
                    maiusculas = true;
                }

                if (97 <= (int) casa && (int) casa <= 122) {
                    minusculas = true;
                }

                if ((33 <= (int) casa && (int) casa <= 47) || (58 <= (int) casa && (int) casa <= 64) || (91 <= (int) casa && (int) casa <= 96) || (123 <= (int) casa && (int) casa <= 126)) {
                    cEspeciais = true;
                }

                if (48 <= (int) casa && (int) casa <= 57) {
                    numeros = true;
                }
            }

            if (maiusculas && minusculas && cEspeciais && tamanho && numeros) {
                valida = true;
                System.out.println("SENHA VALIDA!");
            }

            cont++;
        } while (!valida);
    }

}
