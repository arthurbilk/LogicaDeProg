/*
3e – Faça um programa onde o usuário digita uma senha de 4 caracteres alfabéticos. Utilizando um
laço de repetição, e sem acessar a variável da senha, descubra via força bruta qual foi a senha
originalmente digitada. Anote quanto tempo leva para descobrir a senha.
*/
package pkg18ex3e;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String senha;
        
        System.out.print("Informe uma senha com 4 caracteres alfabeticos: ");
        senha = in.nextLine();
        
        for (int i = 65; i <= 122; i++) {
            if (senha.charAt(0) == i) {
                for (int j = 65; j <= 122; j++) {
                    if (senha.charAt(1) == j) {
                        for (int k = 65; k <= 122; k++) {
                            if (senha.charAt(2) == k) {
                                for (int l = 65; l <= 122; l++) {
                                    if (senha.charAt(3) == l) {
                                        System.out.println("Sua senha eh: " + (char) i + (char) j + (char) k + (char) l);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
}
