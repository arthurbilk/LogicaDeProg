/*
5 - Crie um programa informa o próximo ano de uma data informada no formato
“dd/mm/aaaa” ou “dd/mm/aa”
 */
package pkg18ex5;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String data, data2;
        
        System.out.println("Informe uma data no formato dd/mm/aaaa ou dd/mm/aa");
        data = in.nextLine();
        
        data2 = data;
        
        String aux[] = data.split("/");
        String aux2[] = data2.split("/");
        
        int ano = Integer.parseInt(aux[2]);
        ano++;
        
        String anoNovo = Integer.toString(ano);
        aux2[2] = anoNovo;
        
        System.out.println(aux2[0] + "/" + aux2[1] + "/" + aux2[2]);
        
    }
    
}
