
package q10blk;
import java.util.Scanner;
public class Q10BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int idd;
        
        System.out.println("Informe sua idade");
        idd =in.nextInt();
        
        if(idd < 5){
            System.out.println("Sem categoria");
        } else if (idd <= 7){
            System.out.println("Categoria Infantil A");
        } else if (idd <= 10) {
            System.out.println("Categoria Infantil B");
        } else if (idd <= 13) {
            System.out.println("Categoria Juvenil A");
        } else if (idd <= 17) {
            System.out.println("Categoria Juvenil B");
        } else if (idd <= 60) {
            System.out.println("Adulto");
        } else {
            System.out.println("Categoria idoso");
        }
    }
    
}
