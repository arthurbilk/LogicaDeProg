
package q03blk;
import java.util.Scanner;
public class Q03BLK {

    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        int N;
        
        System.out.println("Digite um numero");
        N = in.nextInt();
        
        if(N%5 == 0||N%7 == 0) {
            System.out.println(N + " eh divisivel por 5 ou 7");
        } else {
            System.out.println(N + " n eh divisvel por 5 ou 7");
        }
       
    }
    
}
