
package q26blk;
import java.util.Scanner;
public class Q26BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int m1, m2, h1, h2, M, H, m, h, soma, multi;
        
        System.out.println("Informe a idade dos homens");
        h1 = in.nextInt();
        h2 = in.nextInt();
        
        System.out.println("Informe a idade das mulheres");
        m1 = in.nextInt();
        m2 = in.nextInt();
        
        if (h1 > h2) {
            H = h1;
            h = h2;
        } else {
            H = h2;
            h = h1;
        }
        
        if (m1 > m2) {
            M = m1;
            m = m2;
        } else {
            M = m2;
            m = m1;
        }
        
        soma = H + m;
        multi = h * M;
        
        System.out.println("O produto da idade do homem mais novo com a mulher mais velha eh: " + multi);
        System.out.println("A soma da idade do homem mais velho e da mulher mais nova eh: " + soma);
        
    }
    
}
