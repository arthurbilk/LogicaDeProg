
/* 3) Faça um programa que funcione como uma urna eletrônica. Primeiramente, indague
quantos votantes há. Apresente as opções abaixo para cada eleitor. Ao final, apresente a
totalização de votos em cada opção (bem como votos nulos) e informe quem foi o
vencedor.
1) Votar no candidato AAA
2) Votar no candidato BBB
3) Votar no candidato CCC
4) Votar em branco */
package pkg14ex3while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int votantes, votoA = 0, votoB = 0, votoC = 0, votoNulo = 0, numA = 1, numB = 2, numC = 3, numN = 4, voto;

        System.out.println("Informe quantos votantes tem");
        votantes = in.nextInt();

        while (votantes != 0) {
            System.out.println("Candidato AAA - 1");
            System.out.println("Candidato BBB - 2");
            System.out.println("Candidato CCC - 3");
            System.out.println("Voto em branco - 4");
            System.out.println("Qual seu voto?");
            voto = in.nextInt();

            switch (voto) {

                case 1:
                    votoA++;
                    break;

                case 2:
                    votoB++;
                    break;

                case 3:
                    votoC++;
                    break;

                case 4:
                    votoNulo++;
                    break;

                default:
                    System.out.println("VOTO INVALIDO");
                    votantes++;
                    break;
            }

            votantes--;

            in.nextLine();
        }

        System.out.println("Candidato AAA: " + votoA + " votos.");
        System.out.println("Candidato BBB: " + votoB + " votos.");
        System.out.println("Candidato CCC: " + votoC + " votos.");
        System.out.println("Votos nulos: " + votoNulo + " votos.");

    }

}
