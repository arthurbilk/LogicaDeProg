package pkg14ex3for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int votoA = 0, votoB = 0, votoC = 0, votoNulo = 0, voto;

        System.out.println("Qual o numero de votantes?");

        for (int i = in.nextInt(); i != 0; i--) {

            System.out.println("Candidato AAA - 1");
            System.out.println("Candidato BBB - 2");
            System.out.println("Candidato CCC - 3");
            System.out.println("Voto em branco - 4");
            System.out.println("Qual seu voto?");
            voto = in.nextInt();

            switch (voto) {

                case 1:
                    votoA++;
                    break;

                case 2:
                    votoB++;
                    break;

                case 3:
                    votoC++;
                    break;

                case 4:
                    votoNulo++;
                    break;

                default:
                    System.out.println("VOTO INVALIDO");
                    i++;
                    break;

            }

        }
        
        System.out.println("Candidato AAA: " + votoA + " votos.");
        System.out.println("Candidato BBB: " + votoB + " votos.");
        System.out.println("Candidato CCC: " + votoC + " votos.");
        System.out.println("Votos nulos: " + votoNulo + " votos.");
    }

}
