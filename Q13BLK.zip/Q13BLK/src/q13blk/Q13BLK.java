package q13blk;

import java.util.Scanner;

public class Q13BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int tipom;
        double n1, n2, n3, media;

        System.out.println("Informe o tipo de media. Digite 1 para aritmetica e 2 pra ponderada");
        tipom = in.nextInt();

        if (tipom == 1) {
            System.out.println("Informe as 3 notas");
            n1 = in.nextDouble();
            n2 = in.nextDouble();
            n3 = in.nextDouble();

            media = (n1 + n2 + n3) / 3;

           if (media < 6) {
                System.out.println("Sua media eh: " + media + ". Reprovado.");
            } else {
                System.out.println("Sua media eh: " + media + ". Aprovado.");
            }

        } else if (tipom == 2) {
            System.out.println("Informe sua nota de maior peso");
            n1 = in.nextDouble();
            
            System.out.println("Informe as notas restantes");
            n2 = in.nextDouble();
            n3 = in.nextDouble();
            
            media = ((n1 * 4) + (n2 * 3) + (n3 * 3))/10;
            
            if (media < 6) {
                System.out.println("Sua media eh: " + media + ". Reprovado.");
            } else {
                System.out.println("Sua media eh: " + media + ". Aprovado.");
            }
        }

    }

}
