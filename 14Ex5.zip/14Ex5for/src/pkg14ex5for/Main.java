
package pkg14ex5for;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int termo, soma = 0, A = 0, B = 1;
        
        System.out.println("Informe o termo em que voce deseja que pare");
        termo = in.nextInt();
        
        for (int cont = 1; cont <= termo; cont++) {
            
            System.out.println(A);

            soma = A + B;
            A = B;
            B = soma;
            
        }
        
    }
    
}
