package pkg14ex5dowhile;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int termo, cont = 1, soma = 0, A = 0, B = 1;

        System.out.println("Informe o termo em que voce deseja que pare");
        termo = in.nextInt();

        do {

            System.out.println(A);

            soma = A + B;
            A = B;
            B = soma;

            cont++;

        } while (cont <= termo);

    }

}
