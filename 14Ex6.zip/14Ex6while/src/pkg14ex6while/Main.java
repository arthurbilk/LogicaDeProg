/* 6) Faça um programa onde o usuário informa um número. Classifique esse número como
primo ou Não Primo. Um número é primo se, e somente se, for divisível de forma inteira
exata apenas por um e por ele mesmo. */
package pkg14ex6while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int numero, cont = 1, div = 0;

        System.out.println("Informe um numero");
        numero = in.nextInt();

        while (cont <= numero) {
            if (numero % cont == 0) {
                div++;
            }
            cont++;
        }
        
        if (div == 2) {
            System.out.println("Numero primo");
        } else {
            System.out.println("Numero nao-primo");
        }
    }

}
