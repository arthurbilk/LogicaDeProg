
package pkg14ex6dowhile;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int numero, cont = 1, div = 0;

        System.out.println("Informe um numero");
        numero = in.nextInt();
        
        do {
            
            if (numero % cont == 0) {
                div++;
            }
            cont++;
            
        } while (cont <= numero);
        
        if (div == 2) {
            System.out.println("Numero primo");
        } else {
            System.out.println("Numero nao-primo");
        }
        
    }
    
}
