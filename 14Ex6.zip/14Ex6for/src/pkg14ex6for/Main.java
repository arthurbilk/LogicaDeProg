package pkg14ex6for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int numero, div = 0;

        System.out.println("Informe um numero");
        numero = in.nextInt();

        for (int cont = 1; cont <= 10; cont++) {

            if (numero % cont == 0) {
                div++;
            }

        }

        if (div == 2) {
            System.out.println("Numero primo");
        } else {
            System.out.println("Numero nao-primo");
        }

    }

}
