package projeto6;

public class Projeto6 {

    public static void main(String[] args) {

        int cont = 10, acum = 0;

        while (cont <= 15) {

            if (cont % 2 == 0) {
                acum += cont;
            }
            cont++;
        }
        
        System.out.println(acum);
    }

}
