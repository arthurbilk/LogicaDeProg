/*
6) Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e
apresente quais números se repetem e quantas vezes.
 */
package pkg17ex6for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int linhasMat = 15, colunasMat = 5, cont = 0;
        int matNums[][] = new int[linhasMat][colunasMat];
        
        for (int linhas = 0; linhas < linhasMat; linhas++) {
            for (int colunas = 0; colunas < colunasMat; colunas++) {
                System.out.println("Informe o numero " + (colunas + 1) + " da linha " + (linhas + 1));
                matNums[linhas][colunas] = in.nextInt();
            }
        }
        
        for (int linhas1 = 0; linhas1 < linhasMat; linhas1++) {
            for (int colunas1 = 0; colunas1 < colunasMat; colunas1++) {
                for (int linhas2 = 0; linhas2 < linhasMat; linhas2++) {
                    for (int colunas2 = 0; colunas2 < colunasMat; colunas2++) {
                        if (matNums[linhas1][colunas1] == matNums[linhas2][colunas2]) {
                            cont++;
                        }
                    }
                }
            }
        }
        
    }
    
}
