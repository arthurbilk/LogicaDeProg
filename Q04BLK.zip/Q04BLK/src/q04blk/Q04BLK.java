
package q04blk;
import java.util.Scanner;
public class Q04BLK {

    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        double N1, N2;
        
        System.out.println("Digite 2 numeros");
        N1 = in.nextDouble();
        N2 = in.nextDouble();
        
        if(N1 == N2) {
            System.out.println("Os numeros sao iguais");
        } else if (N1 > N2) {
            System.out.println(N1 + " eh maior que " + N2);
        } else {
            System.out.println(N2 + " eh maior que " + N1);
        }
    }
    
}
