package questao1simulado;
import java.util.Scanner;
public class Questao1Simulado {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int idade;
        String nome;

        System.out.println("Informe seu nome");
        nome = in.nextLine();

        System.out.println("Informe sua idade");
        idade = in.nextInt();

        if (idade < 0) {
            System.out.println("Idade invalida");
        } else if (idade < 18) {
            System.out.println(nome + " eh jovem, pois tem " + idade + " anos.");
        } else if (idade < 60) {
            System.out.println(nome + " eh adulto, pois tem " + idade + " anos.");
        } else {
            System.out.println(nome + " eh idoso, pois tem " + idade + " anos.");
        }
    }
    
}
