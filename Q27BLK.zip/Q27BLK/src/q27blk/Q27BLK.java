
package q27blk;
import java.util.Scanner;
public class Q27BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double nota1, nota2, nota3, ma, me;
        String nome;
        
        System.out.println("Informe o seu nome");
        nome = in.nextLine();
        
        System.out.println("Informe sua media de exercicios");
        me = in.nextDouble();
        
        System.out.println("Informe suas notas em ordem");
        nota1 = in.nextDouble();
        nota2 = in.nextDouble();
        nota3 = in.nextDouble();
        
        ma = (nota1 + nota2*2 + nota3*3 + me)/7;
        
        if (ma >= 9) {
            System.out.println("Nome do aluno: " + nome);
            System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
            System.out.println("Media dos exercicios: " + me);
            System.out.println("Media de aproveitamento: " + ma);
            System.out.println("Conceito: A");
            System.out.println("APROVADO");
        } else if (ma >= 7.5) {
            System.out.println("Nome do aluno: " + nome);
            System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
            System.out.println("Media dos exercicios: " + me);
            System.out.println("Media de aproveitamento: " + ma);
            System.out.println("Conceito: B");
            System.out.println("APROVADO");
        } else if (ma >= 6) {
            System.out.println("Nome do aluno: " + nome);
            System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
            System.out.println("Media dos exercicios: " + me);
            System.out.println("Media de aproveitamento: " + ma);
            System.out.println("Conceito: C");
            System.out.println("APROVADO");
        } else if (ma >= 4) {
            System.out.println("Nome do aluno: " + nome);
            System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
            System.out.println("Media dos exercicios: " + me);
            System.out.println("Media de aproveitamento: " + ma);
            System.out.println("Conceito: D");
            System.out.println("REPROVADO");
        } else if (ma < 4) {
            System.out.println("Nome do aluno: " + nome);
            System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
            System.out.println("Media dos exercicios: " + me);
            System.out.println("Media de aproveitamento: " + ma);
            System.out.println("Conceito: E");
            System.out.println("REPROVADO");
        }
        
    }
    
}
