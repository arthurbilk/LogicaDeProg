package provetadigital;

import java.util.Scanner;
import java.util.Random;

public class ProvetaDigital {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        Random random = new Random();
        double solido = random.nextDouble(41.0);
        double agua, marcador, valordesc, aguaML = 0;
        String proveta;

        System.out.println("Qual tipo de proveta voce quer?");
        proveta = in.nextLine();

        switch (proveta) {

            case "grande", "g":
                System.out.println("Quantos mL colocar na proveta? Limite de 900mL");
                agua = in.nextDouble();
                
                System.out.println("Enchendo Proveta...");
                System.out.println("Proveta com: ");
                
                while (aguaML < agua) {
                    System.out.println(aguaML + "ML");
                    aguaML = aguaML + 200;
                }
                
                System.out.println("Proveta cheia com sucesso!");

                if (agua > 960) {
                    System.out.println("Proveta transbordou, voce pecou contra o provetismo!");
                } else {

                    solido = Math.round(solido * 10) / 10;
                    marcador = solido + agua;
                    System.out.println("O marcador esta em: " + marcador + "mL");
                    valordesc = marcador - agua;
                    System.out.println("Logo, o volume do solido eh: " + valordesc + "mL");
                }
                break;

            case "media", "m":
                System.out.println("Quantos mL colocar na proveta? Limite de 400mL");
                agua = in.nextDouble();
                
                System.out.println("Enchendo Proveta...");
                System.out.println("Proveta com: ");
                
                while (aguaML < agua) {
                    System.out.println(aguaML + "ML");
                    aguaML = aguaML + 100;
                }
                
                System.out.println("Proveta cheia com sucesso!");

                if (agua > 460) {
                    System.out.println("Proveta transbordou, voce pecou contra o provetismo!");
                } else {

                    solido = Math.round(solido * 10) / 10;
                    marcador = solido + agua;
                    System.out.println("O marcador esta em: " + marcador + "mL");
                    valordesc = marcador - agua;
                    System.out.println("Logo, o volume do solido eh: " + valordesc + "mL");
                }
                break;

            case "pequena", "p":
                System.out.println("Quantos mL colocar na proveta? Limite de 100mL");
                agua = in.nextDouble();
                
                System.out.println("Enchendo Proveta...");
                System.out.println("Proveta com: ");
                
                while (aguaML < agua) {
                    System.out.println(aguaML + "ML");
                    aguaML = aguaML + 30;
                }
                
                System.out.println("Proveta cheia com sucesso!");

                if (agua > 160) {
                    System.out.println("Proveta transbordou, voce pecou contra o provetismo!");
                } else {

                    solido = Math.round(solido * 10) / 10;
                    marcador = solido + agua;
                    System.out.println("O marcador esta em: " + marcador + "mL");
                    valordesc = marcador - agua;
                    System.out.println("Logo, o volume do solido eh: " + valordesc + "mL");
                }
                break;
        }

    }

}
