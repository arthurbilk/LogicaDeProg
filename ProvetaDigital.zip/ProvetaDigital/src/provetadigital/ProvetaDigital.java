
package provetadigital;
import java.util.Scanner;
import java.util.Random;
public class ProvetaDigital {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        Random random = new Random();
        double solido = random.nextDouble(41.0);
        double agua, marcador, valordesc;
        
        System.out.println("Quantos mL colocar na proveta? Limite de 900mL");
        agua = in.nextDouble();
        
        if (agua > 900) {
            System.out.println("Proveta transbordou, voce pecou contra o provetismo!");
        } else {
            
            solido = Math.round(solido * 10) / 10;
            marcador = solido + agua;
            System.out.println("O marcador esta em: " + marcador + "mL");
            valordesc = marcador - agua;
            System.out.println("Logo, o volume do solido eh: " + valordesc + "mL");
            
        }
        
    }
    
}
