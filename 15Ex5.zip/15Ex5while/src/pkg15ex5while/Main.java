package pkg15ex5while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int vet1[] = new int[100];
        int vet2[] = new int[5];
        int cont = 0;
        
        while (cont < vet1.length) {
            int numeroAleatorio = (int) (Math.random() * 101);
            vet1[cont] = numeroAleatorio;
            
            cont++;
        }
        
        cont = 0;
        
        while (cont < vet2.length) {            
            System.out.println("Digite o " + (cont + 1) + "° numero:");
            vet2[cont] = in.nextInt();
            
            cont++;
        }
        
        cont = 0;
        System.out.println("-----Numeros encontrados-----");
        
        while (cont < vet2.length) {            
            boolean encontrou = false;
            int cont2 = 0;
            
            while (cont2 < vet1.length) {                
                if (vet2[cont] == vet1[cont2]) {
                    System.out.println("Numero: " + vet2[cont] + " - Posicao: " + cont2);
                    encontrou = true;
                }
                
                cont2++;
            }
            
            if (!encontrou) {
                System.out.println("Numero: " + vet2[cont] + " - Posicao: NAO ENCONTRADO");
            }
            
            cont++;
        }
    }
    
}
