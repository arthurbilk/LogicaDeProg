package pkg15ex5for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int tamanhoVet1 = 100, tamanhoVet2 = 5, contIguais = 0, cont = 0;
        int vet1[] = new int[tamanhoVet1];
        int vet2[] = new int[tamanhoVet2];
        
        // aleatorio
        for (int i = 0; i < tamanhoVet1; i++) {
            int numeroAleatorio = (int) (Math.random() * 101);
            vet1[i] = numeroAleatorio;
        }

        for (int i = 0; i < tamanhoVet2; i++) {
            System.out.println("Digite o " + (i + 1) + "° numero:");
            vet2[i] = in.nextInt();
        }

        for (int i = 0; i < tamanhoVet2; i++) {
            for (int j = 0; j < tamanhoVet1; j++) {
                if (vet2[i] == vet1[j]) {
                    contIguais++;
                }
            }
        }
        
        int vetNumIguais[] = new int [contIguais];
        int vetPosicao[] = new int [contIguais];
        
        for (int i = 0; i < tamanhoVet2; i++) {
            for (int j = 0; j < tamanhoVet1; j++) {
                if (vet2[i] == vet1[j]) {
                   vetNumIguais[(cont)] = vet2[i];
                   vetPosicao[(cont)] = j;
                   
                   cont++;
                }
            }
        }
        
        if (contIguais == 0) {
            System.out.println("Nenhum numero igual");
        } else {
            System.out.println("-----Numeros iguais-----");
            for (int i = 0; i < contIguais; i++) {
                System.out.println("Numero: " + vetNumIguais[i] + " - Posicao: " + vetPosicao[i]);
            }
        }
    }
    
}
