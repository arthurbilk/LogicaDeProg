package pkg15ex5do;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int vet1[] = new int[100];
        int vet2[] = new int[5];
        int cont = 0;
        
        do {
            int numeroAleatorio = (int) (Math.random() * 101);
            vet1[cont] = numeroAleatorio;
            
            cont++;
        } while (cont < vet1.length);
        
        cont = 0;
        
        do {
            System.out.println("Digite o " + (cont + 1) + "° numero:");
            vet2[cont] = in.nextInt();
            
            cont++;
        } while (cont < vet2.length);
        
        cont = 0;
        System.out.println("-----Numeros encontrados-----");
        
        do {
            boolean encontrou = false;
            int cont2 = 0;
            
            do {
                if (vet2[cont] == vet1[cont2]) {
                    System.out.println("Numero: " + vet2[cont] + " - Posicao: " + cont2);
                    encontrou = true;
                }
                
                cont2++;
            } while (cont2 < vet1.length);
            
            if (!encontrou) {
                System.out.println("Numero: " + vet2[cont] + " - Posicao: NAO ENCONTRADO");
            }
            
            cont++;
            
        } while (cont < vet2.length);
    }
    
}
