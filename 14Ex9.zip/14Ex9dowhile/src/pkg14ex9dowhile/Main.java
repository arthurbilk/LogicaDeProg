package pkg14ex9dowhile;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        // variaveis de id
        int idVendas = 1, idTroco = 2, idSair = 3, menu;
        String menuProduto;

        // variaveis de preço
        double precoAgua = 3.5, precoSalgado = 5, precoSalada = 7.5, acumPrecoTotal = 0, precoTotal, troco, valorPago;
        int quant;

        do {

            System.out.println("----------------MENU------------------");
            System.out.println("1 - Registrar venda de um produto");
            System.out.println("2 - Apresentar total e calcular troco");
            System.out.println("3 - Sair");
            System.out.println("--------------------------------------");
            System.out.println("Informe qual opcao acima voce deseja:");

            menu = in.nextInt();

            if (menu == idVendas) {

                System.out.println("-----------REGISTRAR VENDA------------");
                System.out.println("a – Agua - R$ 3,5");
                System.out.println("b – Salgado R$ 5,00");
                System.out.println("c – Salada de Frutas R$ 7,50");
                System.out.println("");

                in.nextLine();

                System.out.println("Informe qual produto voce quer registrar venda:");
                menuProduto = in.nextLine();

                System.out.println("Informe qual a quantidade do produto:");
                quant = in.nextInt();

                switch (menuProduto.toLowerCase()) {

                    case "agua", "a":

                        precoTotal = precoAgua * quant;
                        acumPrecoTotal += precoTotal;

                        System.out.println("Valor gasto: R$" + precoTotal);

                        precoTotal = 0;
                        break;

                    case "salgado", "b":

                        precoTotal = precoSalgado * quant;
                        acumPrecoTotal += precoTotal;

                        System.out.println("Valor gasto: R$" + precoTotal);

                        precoTotal = 0;
                        break;

                    case "salada", "c":

                        precoTotal = precoSalada * quant;
                        acumPrecoTotal += precoTotal;

                        System.out.println("Valor gasto: R$" + precoTotal);

                        precoTotal = 0;
                        break;

                    default:

                        System.out.println("CODIGO INVALIDO");
                        break;

                }

            } else if (menu == idTroco) {

                if (acumPrecoTotal > 0) {

                    System.out.println("-----------------PAGAMENTO-----------------");
                    System.out.println("Valor total da compra: R$" + acumPrecoTotal);
                    System.out.println("-------------------------------------------");

                    System.out.println("Qual o valor do pagamento?");
                    valorPago = in.nextDouble();

                    System.out.println("");

                    while (valorPago < acumPrecoTotal) {

                        System.out.println("Valor insuficiente");
                        System.out.println("");

                        System.out.println("Qual o valor do pagamento?");
                        valorPago = in.nextDouble();

                    }

                    troco = valorPago - acumPrecoTotal;

                    System.out.println("Valor do troco: R$" + troco);

                    acumPrecoTotal = 0;

                } else {

                    System.out.println("Nenhum produto registrado");

                }

            } else if (menu != idSair) {

                System.out.println("OPCAO INVALIDA");

            }

        } while (menu != idSair);

        System.out.println("------------------------------------");
        System.out.println("Agradecemos a preferencia, ate mais!");

    }

}