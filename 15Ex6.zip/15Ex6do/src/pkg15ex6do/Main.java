
package pkg15ex6do;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int quant = 5, cont = 0;
        double consumoMaisEconomico = 0, consumoMenosEconomico = 0, valorCombustivel;
        String nomeMaisEconomico = "", nomeMenosEconomico = "";
        String[] nomeCarro = new String[quant];
        double[] consumo = new double[quant];
        double[] valor780 = new double[quant];
        
        do {
            System.out.println("Automovel N" + (cont + 1) + ": Qual o modelo?");
            nomeCarro[cont] = in.nextLine();
            
            System.out.println("Automovel N" + (cont + 1) + ": Qual o consumo? (km/L)");
            consumo[cont] = in.nextDouble();
            in.nextLine();
            
            cont++;
        } while (cont < quant);
        
        cont = 0;
        
        System.out.println("Qual o valor do litro do combustível?");
        valorCombustivel = in.nextDouble();
        
        do {
            if (consumo[cont] > consumoMaisEconomico) {
                consumoMaisEconomico = consumo[cont];
                nomeMaisEconomico = nomeCarro[cont];
            }
            if (cont == 0) {
                consumoMenosEconomico = consumo[cont];
                nomeMenosEconomico = nomeCarro[cont];
            } else if (consumo[cont] < consumoMenosEconomico) {
                consumoMenosEconomico = consumo[cont];
                nomeMenosEconomico = nomeCarro[cont];
            }
            cont++;
        } while (cont < quant);
        
        cont = 0;
        
        System.out.println("");
        System.out.println("Mais economico: " + nomeMaisEconomico + " - Consumo: " + consumoMaisEconomico + "km/L");
        System.out.println("Menos economico: " + nomeMenosEconomico + " - Consumo: " + consumoMenosEconomico + "km/L");
        System.out.println("");
        
        System.out.println("-----Consumo em 780Km:-----");
        do {
            valor780[cont] = Math.round(((780 / consumo[cont]) * valorCombustivel) * 100.0) / 100.0;
            System.out.println("  -" + nomeCarro[cont] + ": R$" + valor780[cont]);
            
            cont++;
        } while (cont < quant);
    }
    
}
