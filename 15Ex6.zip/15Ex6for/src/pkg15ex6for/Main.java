/*
6. Preencha dois vetores. Um com modelos de
automóveis e outro com o consumo médio dos mesmos.
Peça ao usuário também o valor do combustível.
Informe:

- o veículo mais econômico
- o veículo menos econômico
- Quanto cada veículo gastará em R$ para
percorrer 780km
*/
package pkg15ex6for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int quant = 5;
        double consumoMaisEconomico = 0, consumoMenosEconomico = 0, valorCombustivel;
        String nomeMaisEconomico = "", nomeMenosEconomico = "";
        String[] nomeCarro = new String[quant];
        double[] consumo = new double[quant];
        double[] valor780 = new double[quant];
        
        // valores
        for (int i = 0; i < quant; i++) {
            System.out.println("Automovel N" + (i + 1) + ": Qual o modelo?");
            nomeCarro[i] = in.nextLine();
            
            System.out.println("Automovel N" + (i + 1) + ": Qual o consumo? (km/L)");
            consumo[i] = in.nextDouble();
            in.nextLine();
        }
        
        System.out.println("Qual o valor do litro do combustível?");
        valorCombustivel = in.nextDouble();
        
        // mais e menos economico
        for (int i = 0; i < quant; i++) {
            if (consumo[i] > consumoMaisEconomico) {
                consumoMaisEconomico = consumo[i];
                nomeMaisEconomico = nomeCarro[i];
            }
            if (i == 0) {
                consumoMenosEconomico = consumo[i];
                nomeMenosEconomico = nomeCarro[i];
            } else if (consumo[i] < consumoMenosEconomico) {
                consumoMenosEconomico = consumo[i];
                nomeMenosEconomico = nomeCarro[i];
            }
        }
        
        System.out.println("");
        System.out.println("Mais economico: " + nomeMaisEconomico + " - Consumo: " + consumoMaisEconomico + "km/L");
        System.out.println("Menos economico: " + nomeMenosEconomico + " - Consumo: " + consumoMenosEconomico + "km/L");
        System.out.println("");
        
        System.out.println("-----Consumo em 780Km:-----");
        for (int i = 0; i < quant; i++) {
            valor780[i] = Math.round(((780 / consumo[i]) * valorCombustivel) * 100.0) / 100.0;
            System.out.println("  -" + nomeCarro[i] + ": R$" + valor780[i]);
        }
        
    }
    
}
