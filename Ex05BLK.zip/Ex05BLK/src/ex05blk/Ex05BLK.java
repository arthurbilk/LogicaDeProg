package ex05blk;

import java.util.Scanner;

public class Ex05BLK {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        double comp, alt, larg, vol;

        System.out.println("Digite em cm a altura, comprimento e largura de um retangulo");
        alt = teclado.nextDouble();
        comp = teclado.nextDouble();
        larg = teclado.nextDouble();

        vol = comp * alt * larg;

        System.out.println("O volume do retamgulo é: " + vol + "cm3");
    }

}
