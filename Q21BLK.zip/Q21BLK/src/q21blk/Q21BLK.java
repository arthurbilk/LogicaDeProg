
package q21blk;
import java.util.Scanner;
public class Q21BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int cmch, fimh, cmcm, fimm, cmchm,fimhm, cmccalc, fimcalc, duracao, temph, tempm;
        
        System.out.println("Insira a hora e o minuto de inicio");
        cmch = in.nextInt();
        cmcm = in.nextInt();
        
        System.out.println("Insira a hora e o minuto de fim");
        fimh = in.nextInt();
        fimm = in.nextInt();
        
        cmchm = cmch * 60;
        fimhm = fimh * 60;
        
        cmccalc = cmcm + cmchm;
        fimcalc = fimm + fimhm;
        
        if (cmccalc < fimcalc) {
            duracao = fimcalc - cmccalc;
        } else {
            duracao = (fimcalc + 1440) - cmccalc;
        }
        
        temph = duracao / 60;
        tempm = duracao % 60;
        
        System.out.println("A duracao do jogo foi de " + temph + " hora(s) e " + tempm + " minuto(s)");
        
    }
    
}
