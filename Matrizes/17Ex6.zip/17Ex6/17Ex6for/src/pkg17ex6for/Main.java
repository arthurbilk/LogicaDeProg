/*
6) Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e
apresente quais números se repetem e quantas vezes.
 */
package pkg17ex6for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int linhasMat = 2, colunasMat = 2, cont = 0, tamanhoVet = linhasMat * colunasMat;
        int vetNums[] = new int[tamanhoVet];
        int vetCont[] = new int[tamanhoVet];
        int matNums[][] = new int[linhasMat][colunasMat];

        for (int linhas = 0; linhas < linhasMat; linhas++) {
            for (int colunas = 0; colunas < colunasMat; colunas++) {
                System.out.println("Informe o numero " + (colunas + 1) + " da linha " + (linhas + 1));
                matNums[linhas][colunas] = in.nextInt();
            }
        }

        for (int linhas1 = 0; linhas1 < linhasMat; linhas1++) {
            for (int colunas1 = 0; colunas1 < colunasMat; colunas1++) {
                vetNums[cont] = matNums[linhas1][colunas1];
                cont++;
            }
        }

        for (int i = 0; i < tamanhoVet; i++) {
            for (int j = 0; j < tamanhoVet; j++) {
                if (vetNums[i] == vetNums[j]) {
                    vetCont[i]++;
                }
            }
        }

        for (int i = 0; i < tamanhoVet; i++) {
            if (vetCont[i] > 1) {
                boolean jaMostrou = false;
                
                for (int j = 0; j < i; j++) {
                    if (vetNums[i] == vetNums[j]) {
                        jaMostrou = true;
                    }
                }
                
                if (!jaMostrou) {
                    System.out.println(vetNums[i] + " apareceu " + vetCont[i] + " vezes");
                }
            }
        }

    }

}
