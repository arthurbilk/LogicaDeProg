/*
4 – Crie um programa que apresenta o primeiro nome de um nome completo de uma
pessoa que foi digitado pelo usuário;
 */
package pkg18ex4;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String nomeCompleto, nome;
        
        System.out.println("Qual seu nome completo?");
        nomeCompleto = in.nextLine();
        
        String aux[] = nomeCompleto.split(" ");
        nome = aux[0];
        
        System.out.println("Seu nome eh: " + nome);
    }
    
}
