
package acidosnucleicos;
import java.util.Scanner;
public class AcidosNucleicos {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double altura, peso, indice;
        
        System.out.println("Informe seu peso em kg");
        peso = in.nextDouble();
        
        System.out.println("Informe sua altura em m");
        altura = in.nextDouble();
        
        indice = peso/Math.pow(altura, 2);
        
        System.out.println("Seu IMC eh: " + indice);
    }
    
}
