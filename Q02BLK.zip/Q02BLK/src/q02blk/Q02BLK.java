
package q02blk;
import java.util.Scanner;
public class Q02BLK {

    public static void main(String[] args) {
        
        Scanner t = new Scanner(System.in);
        int N;
        
        System.out.println("Digite um numero");
        N = t.nextInt();
        
        if(N%6 == 0) {
            System.out.println(N + " eh divisivel por 2 e 3");
        } else {
            System.out.println(N + " n eh divisivel por 2 e 3");
        }
    }
    
}
