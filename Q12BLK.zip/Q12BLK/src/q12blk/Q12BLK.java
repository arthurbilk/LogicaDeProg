
package q12blk;
import java.util.Scanner;
public class Q12BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int num;
        
        System.out.println("Insira um numero");
        num = in.nextInt();
        
        if (num >= 0) {
            if (num == 0) {
                System.out.println("0 eh par");
            } else if (num % 2 == 0) {
                System.out.println(num + " eh par e positivo");
            } else {
                System.out.println(num + " eh impar e positivo");
            }
        } else if (num % 2 == 0) {
            System.out.println(num + " eh par e negativo");
        } else {
             System.out.println(num + " eh impar e negativo");
        }
    }
    
}
