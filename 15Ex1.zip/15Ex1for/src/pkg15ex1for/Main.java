/*1. Preencha um vetor com 5 números informados
pelo usuário. Depois apresente os números pares.*/

package pkg15ex1for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        
        int quant = 5;
        int vetNum[] = new int[quant];
        
        for (int cont = 0; cont < quant; cont++) {
            
            System.out.println("Informe o numero " + (cont + 1) + ":");
            vetNum[cont] = in.nextInt();
            
        }
        
        for (int cont = 0; cont < quant; cont++) {
            
            if (vetNum[cont] % 2 == 0) {

                System.out.println("Numero " + (cont + 1) + ": " + vetNum[cont]);

            } else {
            
                System.out.println("Numero " + (cont + 1) + ": impar");
            
            }
            
        }
        
    }
    
}
