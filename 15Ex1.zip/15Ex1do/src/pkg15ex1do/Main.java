/*1. Preencha um vetor com 5 números informados
pelo usuário. Depois apresente os números pares.*/

package pkg15ex1do;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);

        int quant = 5, cont = 0;
        int vetNum[] = new int[quant];
        
        do {
            
            System.out.println("Informe o numero " + (cont + 1) + ":");
            vetNum[cont] = in.nextInt();
            
            cont++;
            
        } while (cont < quant);
        
        cont = 0;
        
        do {
            
            if (vetNum[cont] % 2 == 0) {

                System.out.println("Numero " + (cont + 1) + ": " + vetNum[cont]);

            } else {
            
                System.out.println("Numero " + (cont + 1) + ": impar");
            
            }

            cont++;
            
        } while (cont < quant);
        
    }
    
}
