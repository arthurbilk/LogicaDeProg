/*1. Preencha um vetor com 5 números informados
pelo usuário. Depois apresente os números pares.*/

package pkg15ex1while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int quant = 5, cont = 0;
        int vetNum[] = new int[quant];

        while (cont < quant) {

            System.out.println("Informe o " + (cont + 1) + "o numero:");
            vetNum[cont] = in.nextInt();

            cont++;

        }

        cont = 0;

        while (cont < quant) {

            if (vetNum[cont] % 2 == 0) {

                System.out.println("Numero " + (cont + 1) + ": " + vetNum[cont]);

            } else {
            
                System.out.println("Numero " + (cont + 1) + ": impar");
            
            }

            cont++;

        }
    }

}
