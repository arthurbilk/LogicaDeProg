/*
7. Faça um programa que preencha três vetores
com cinco posições cada. No primeiro vetor armazene
os nomes dos funcionários. No segundo o salário e no
terceiro o tempo de serviço de cada um. Mostre um
primeiro relatório com os nomes dos funcionários que
não terão aumento. E um segundo relatório com os
nomes e os novos salários dos funcionários que terão
aumento. Os funcionários que terão aumento serão
aqueles que tem tempo de serviço superior a 5 anos ou
salário inferior a R$ 1940. Sabe-se que os funcionários
que satisfizerem as duas condições terão 35% de
aumento. Para o funcionário que se enquadre apenas
com o tempo de serviço terá 25% de aumento. E se o
salário for inferior ao valor, terá 15% de aumento.
 */
package pkg15ex7for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int quant = 5, contAumento = 0, contNaoAumento = 0;
        String[] nomeFuncionario = new String[quant];
        double[] salarios = new double[quant];
        int[] tempoServico = new int[quant];
        
        for (int i = 0; i < quant; i++) {
            System.out.println("Informe o nome do funcionario N" + (i + 1) + ":");
            nomeFuncionario[i] = in.nextLine();
            
            System.out.println("Informe o salario do funcionario N" + (i + 1) + ":");
            salarios[i] = in.nextDouble();
            
            System.out.println("Informe o tempo de servico (em anos) do funcionario N" + (i + 1) + ":");
            tempoServico[i] = in.nextInt();
            in.nextLine();
        }
        
        for (int i = 0; i < quant; i++) {
            if (salarios[i] < 1940 || tempoServico[i] > 5) {
                contAumento++;
            } else {
                contNaoAumento++;
            }
        }
        
        String[] nomeFuncionarioAumento = new String[contAumento];
        double[] salariosAumento = new double[contAumento];
        int[] tempoServicoAumento = new int[contAumento];
        
        String[] nomeFuncionarioNaoAumento = new String[contNaoAumento];
        double[] salariosNaoAumento = new double[contNaoAumento];
        int[] tempoServicoNaoAumento = new int[contNaoAumento];
        
        for (int i = 0; i < quant; i++) {
            
        }
    }
    
}
