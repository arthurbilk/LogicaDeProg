package q09blk;

import java.util.Scanner;

public class Q09BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int n1, n2;

        System.out.println("Informe 2 numeros");
        n1 = in.nextInt();
        n2 = in.nextInt();

        if (n1 % n2 == 0 || n2 % n1 == 0) {
            System.out.println("Os numeros sao multiplos");
        } else {
            System.out.println("Os numeros nao sao multiplos");
        }
    }

}
