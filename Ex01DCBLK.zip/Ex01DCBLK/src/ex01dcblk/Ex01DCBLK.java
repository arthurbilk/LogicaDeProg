package ex01dcblk;
import java.util.Scanner;
public class Ex01DCBLK {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        double n1, n2, media;
        
        System.out.println("Digite as notas");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        
        media = (n1 + n2)/2;
        
        if (media < 6) {
            System.out.println("Em exame");
        } else {
            System.out.println("Aprovado");
        }
        
    }
    
}
