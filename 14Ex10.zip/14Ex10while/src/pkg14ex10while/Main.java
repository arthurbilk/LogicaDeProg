/*10) Faça um programa onde o usuário digita várias cores. Ex: verde, amarelo, azul...
Determine e informe quantas vezes a cor azul foi digitada. Informe também se a cor verde
ou vermelha foi mais digitada.*/

package pkg14ex10while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        
        // contadores
        int contAzul = 0, contVermelho = 0, contVerde = 0;
        
        String cor = "", condicao = "";
        
        System.out.println("Digite uma cor. Quando quiser, digite fim para a contagem terminar");
        cor = in.nextLine().toLowerCase();
        
        while (!cor.equals("fim") && !cor.equals("final")) {
            
            switch (cor.toLowerCase()) {
                
                case "verde":
                    
                    contVerde++;
                    break;
                    
                case "azul":
                    
                    contAzul++;
                    break;
                    
                case "vermelho":
                    
                    contVermelho++;
                    break;
                    
            }
            
            System.out.println("Digite novamente:");
            cor = in.nextLine().toLowerCase();
            
        }
        
        if (contAzul == 1) {
            
            System.out.println("Cor azul foi digitada " + contAzul + " vez");
            
        } else {
        
            System.out.println("Cor azul foi digitada " + contAzul + " vezes");
        
        }
        
        if (contVerde > contVermelho) {
            
            System.out.println("Verde foi digitado mais vezes que vermelho");
            
        } else if (contVerde < contVermelho) {
            
            System.out.println("Vermelho foi mais digitado que verde");
            
        } else {
            
            System.out.println("Verde e vermelho foram digitados igualmente");
            
        }
        
    }

}
