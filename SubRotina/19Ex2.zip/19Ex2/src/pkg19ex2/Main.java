/*
2. Crie um programa que receba dois números inteiros positivos por
parâmetro e retorne a soma dos N números inteiros existentes entre eles.
 */
package pkg19ex2;

import java.util.Scanner;

public class Main {
    
    static int somaN (int a, int b) {
        int soma = 0;
        
        if (a > b) {
            for (int i = b + 1; i < a; i++) {
                soma += i;
            }
        }
        if (a < b) {
            for (int i = a + 1; i < b; i++) {
                soma += i;
            }
        }
        return soma;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe dois numeros: ");
        int valor1 = in.nextInt();
        int valor2 = in.nextInt();
        
        int resposta = somaN(valor1, valor2);
        System.out.println("Soma de todos os valores entre eles: " + resposta);
    }
    
}
