/*
Um programa com uma subrotina que
recebe um vetor de números por
parâmetro e retorna o maior número.
 */
package pkg19cex3;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] num = {1, 17, 5, -2, 15};
        
        System.out.println(maior(num));
    }
    
    static int maior(int num[]) {
        int maior = num[0];
        
        for (int i = 0; i < num.length; i++) {
            if (num[i] > maior) {
                maior = num[i];
            }
        }
        
        return maior;
    }
    
}
