/*
Um programa que use recursividade para determinar se uma palavra é um
palíndromo. Portanto, não utilize laços de repetição.
 */
package pkg19cex2;

import java.util.Scanner;

public class Main {
    
    static boolean palindromo (String p) {
        
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe uma palavra: ");
        String palavra = in.nextLine();
        
        if (palindromo(palavra)) {
            System.out.println("Palindromo.");
        }
        if (!palindromo(palavra)) {
            System.out.println("Nao palindromo.");
        }
    }
    
}
