/*
Um programa com uma subrotina que
recebe um vetor de números (double)
por parâmetro e retorna o valor médio
desses números.
 */
package pkg19cex4;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double[] num = {1.1, 17, 5, -2.6, 37};
        
        System.out.println(media(num));
    }
    
    static double media(double num[]) {
        double acum = 0;
        
        for (int i = 0; i < num.length; i++) {
            acum += num[i];
        }
        
        double media = acum / num.length;
        return media;
    }
    
}
