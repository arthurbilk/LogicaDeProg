/*
8. Crie uma sub-rotina que receba
5 valores inteiros, determine e
mostre o maior e o menor deles.
O programa principal deve indagar
esses números ao usuário.
 */
package pkg19ex8;

import java.util.Scanner;

public class Main {
    
    static void verificacao (int[] numeros) {
        int maior = numeros[0], menor = numeros[0];
        
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
        }
        
        System.out.println("Maior: " + maior);
        System.out.println("Menor: " + menor);
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] numeros = new int[5];
        
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Numero " + (i + 1) + ": ");
            numeros[i] = in.nextInt();
        }
        
        verificacao(numeros);
    }
    
}
