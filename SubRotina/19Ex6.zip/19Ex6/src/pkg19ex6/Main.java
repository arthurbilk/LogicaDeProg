/*
6. Crie uma sub-rotina que receba como
parâmetro o início e o término de um jogo,
ambos subdivididas em dois valores inteiros
distintos: horas e minutos (portanto, serão 4
parâmetros). A sub-rotina deverá retornar a
duração expressa em minutos, considerando
que a duração máxima é de 24 horas e que um
jogo pode iniciar em um dia e terminar em outro.
 */
package pkg19ex6;

import java.util.Scanner;

public class Main {
    
    static int duracao (int hi, int hf, int mi, int mf) {
        int total;
        
        mi += hi * 60;
        mf += hf * 60;
        
        if (hi > hf) {
            total = mf + 1440 - mi;
        } else {
            total = mf - mi;
        }
        
        return total;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Hora e o minuto de inicio do jogo:");
        int horaInicio = in.nextInt();
        int minutoInicio = in.nextInt();
        
        System.out.println("Hora e o minuto de fim do jogo:");
        int horaFim = in.nextInt();
        int minutoFim = in.nextInt();
        
        int total = duracao(horaInicio, horaFim, minutoInicio, minutoFim);
        
        System.out.println("Total de minutos: " + total);
    }
    
}
