/*
7. Crie uma sub-rotina que recebe um
número por parâmetro e retorna true
caso seja um número primo, e false
caso contrário. O programa principal
deve permitir testar a sub-rotina e
apresentar o texto “Primo” ou “Não
primo” coerentemente.
 */
package pkg19ex7;

import java.util.Scanner;

public class Main {
    
    static boolean verificacao (int a) {
        int cont = 1 , divisores = 0;
        boolean primo = false;
        
        while (cont <= a) {            
            if (a % cont == 0) {
                divisores++;
            }
            cont++;
        }
        
        if (divisores == 2) {
            primo = true;
        }
        
        return primo;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe um numero: ");
        int numero = in.nextInt();
        
        boolean primo = verificacao(numero);
        
        if (primo) {
            System.out.println("Primo");
        } else {
            System.out.println("Nao-primo");
        }
    }
    
}
