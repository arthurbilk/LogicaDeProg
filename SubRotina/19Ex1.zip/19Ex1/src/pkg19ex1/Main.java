/*
1. Crie um programa com uma
sub-rotina que calcula e retorna
a multiplicação de dois números
informados pelo usuário;
 */
package pkg19ex1;
import java.util.Scanner;
public class Main {
    
    static int mult(int a, int b) {
        int resposta;
        resposta = a * b;
        return resposta;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe dois numeros: ");
        int valor1 = in.nextInt();
        int valor2 = in.nextInt();
        
        int resposta = mult(valor1, valor2);
        System.out.println("Resultado: " + resposta);
    }
    
}
