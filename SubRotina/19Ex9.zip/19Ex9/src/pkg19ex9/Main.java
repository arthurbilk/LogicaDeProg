/*
9- Criem uma sub-rotina que recebe por parâmetro
o nome completo de uma pessoa e retorna esse
nome com os nomes do meio abreviados.

Exemplo:
Paulo Eduardo Marco Silva → Paulo E. M. Silva
 */
package pkg19ex9;

import java.util.Scanner;

public class Main {
    
    static String abreviador(String nomeCompleto) {
        String[] divisao = nomeCompleto.split(" ");
        
        for (int i = 1; i < divisao.length - 1; i++) {
            if (!(divisao[i].equals("da") || divisao[i].equals("de") || divisao[i].equals("do") || divisao[i].equals("dos") || divisao[i].equals("das"))) {
                divisao[i] = divisao[i].charAt(0) + ".";
            }
        }
        
        for (int i = 0; i < divisao.length; i++) {
            System.out.print(divisao[i] + " ");
        }
        
        return nomeCompleto;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Seu nome completo: ");
        String nomeCompleto = in.nextLine();
        
        String nomeAbreviado = abreviador(nomeCompleto);
    }
    
}
