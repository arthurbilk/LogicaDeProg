/*
Um programa que use recursividade para determinar se uma palavra é um
palíndromo. Portanto, não utilize laços de repetição.
 */
package pkg19cex2;

import java.util.Scanner;

public class Main {
    
    static boolean palindromo (String p, int i) {
        p = p.toLowerCase();
        
        if (p.length() == 1) {
            return true;
        }
        if (i == p.length() / 2) {
            return true;
        }
        if (p.charAt(i) != p.charAt(p.length() - (i + 1))) {
            return false;
        }
        
        return palindromo(p, i + 1);
        
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int posicao = 0;
        boolean vazio = true;
        String palavra = "";
        
        while (vazio) {            
            System.out.println("Informe uma palavra: ");
            palavra = in.nextLine();
            
            if (!palavra.equals("")) {
                vazio = false;
            }
        }
        
        if (palindromo(palavra, posicao)) {
            System.out.println("Palindromo.");
        }
        if (!palindromo(palavra, posicao)) {
            System.out.println("Nao palindromo.");
        }
    }
    
}
