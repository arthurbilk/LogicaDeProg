/*
Um programa com uma subrotina que
receba um vetor e um número, e diga
se o número está presente
(retornando true/false).
 */
package pkg19cex5;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] num = {1, 17, 5, -2, 15};
        int prey = 5;
        
        if (hunter(num, prey)) {
            System.out.println("Numero encontrado");
        }
        if (!hunter(num, prey)) {
            System.out.println("Numero nao encontrado");
        }
    }
    
    static boolean hunter(int num[], int a) {
        for (int i = 0; i < num.length; i++) {
            if (a == num[i]) {
                return true;
            }
        }
        return false;
    }
    
}
