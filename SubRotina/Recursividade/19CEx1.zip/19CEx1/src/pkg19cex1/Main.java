
package pkg19cex1;

public class Main {
    
    static void contador(int n) {
        if (n == 0) {
            return;
        }
        
        System.out.println(n);
        
        contador(n - 1);
    }
    
    public static void main(String[] args) {
        contador(100);
    }
    
}
