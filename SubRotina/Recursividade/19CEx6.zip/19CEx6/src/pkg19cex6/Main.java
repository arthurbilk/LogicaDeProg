/*
Um programa com uma subrotina que
receba um vetor e retorna outro vetor
com os elementos invertidos.
Exemplo: {1, 2, 3, 4} → {4, 3, 2, 1}
 */
package pkg19cex6;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        int[] num = {1, 17, 5, -2, 15};
        
        System.out.println("Vetor: ");
        for (int i = 0; i < num.length; i++) {
            if (i == num.length - 1) {
                System.out.println(num[i] + ".");
            }
            System.out.print(num[i] + ", ");
        }
        
        int[] novoVetor = inverter(num);
        System.out.println("Novo vetor: ");
        for (int i = 0; i < novoVetor.length; i++) {
            if (i == novoVetor.length - 1) {
                System.out.println(novoVetor[i] + ".");
            }
            System.out.print(novoVetor[i] + ", ");
        }
    }
    
    static int[] inverter (int num[]) {
        int[] num2 = new int[num.length];
        
        for (int i = 0; i < num.length; i++) {
            num2[i] = num[num.length - 1 - i];
        }
        
        return num2;
    }
    
}
