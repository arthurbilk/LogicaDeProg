package pkg19cex7;

import java.util.Scanner;

public class Main {
    
    static int[] repetidos (int[] num) {
        int[] novoVetor = new int[num.length];
        int quantidade = 0;
        
        for (int i = 0; i < num.length; i++) {
            boolean presente = false;
            
            for (int j = 0; j < quantidade; j++) {
                if (num[i] == novoVetor[j]) {
                    presente = true;
                    break;
                }
            }
            
            if (!presente) {
                novoVetor[quantidade] = num[i];
                quantidade++;
            }
        }
        return novoVetor;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] num = {5, 10, 15, 20, 25, 853, 10, 10, 15};
        
        int[] novoVetor = repetidos(num);
        
        System.out.println("Novo vetor: ");
        for (int i = 0; i < novoVetor.length; i++) {
            if (novoVetor[i] != 0) {
                System.out.println("   ." + novoVetor[i]);
            }
        }
    }
    
}
