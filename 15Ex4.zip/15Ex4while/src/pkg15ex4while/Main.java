
package pkg15ex4while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int quant = 5, cont = 0, contFrutas = 0, contAnimais = 0;
        String animais[] = new String[quant];
        String frutas[] = new String[quant];
        String animaisFrutas[] = new String[(quant * 2)];
        
        while (cont < quant) {            
            System.out.println("Informe o animal numero " + (cont + 1));
            animais[cont] = in.nextLine();
            
            System.out.println("Informe a fruta numero " + (cont + 1));
            frutas[cont] = in.nextLine();
            
            cont++;
        }
        
        cont = 0;
        
        while (cont < (quant * 2)) {            
            if (cont % 2 == 0) {
                animaisFrutas[cont] = animais[contAnimais];
                contAnimais++;
            }
            if (cont % 2 != 0) {
                animaisFrutas[cont] = frutas[contFrutas];
                contFrutas++;
            }
            cont++;
        }
        
        cont = 0;
        
        while (cont < (quant * 2)) {            
            System.out.println(animaisFrutas[cont]);
            cont++;
        }
    }
    
}
