/*
4. Preencha 2 vetores com 5 dados em cada. Um de animais e outro de frutas. Em
um terceiro intercale as informaçoes e apresente as
 */
package pkg15ex4for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int quant = 5, contFrutas = 0, contAnimais = 0;
        String animais[] = new String[quant];
        String frutas[] = new String[quant];
        String animaisFrutas[] = new String[(quant * 2)];
        
        for (int i = 0; i < quant; i++) {
            System.out.println("Informe o animal numero " + (i + 1));
            animais[i] = in.nextLine();
            
            System.out.println("Informe a fruta numero " + (i + 1));
            frutas[i] = in.nextLine();
        }
        
        for (int i = 0; i < (quant * 2); i++) {
            if (i % 2 == 0) {
                animaisFrutas[i] = animais[contAnimais];
                contAnimais++;
            }
            if (i % 2 != 0) {
                animaisFrutas[i] = frutas[contFrutas];
                contFrutas++;
            }
        }
        
        for (int i = 0; i < (quant * 2); i++) {
            System.out.println(animaisFrutas[i]);
        }
    }
    
}
