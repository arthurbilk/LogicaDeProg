
package pkg15ex4do;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int quant = 2, cont = 0, contFrutas = 0, contAnimais = 0;
        String animais[] = new String[quant];
        String frutas[] = new String[quant];
        String animaisFrutas[] = new String[(quant * 2)];
        
        do {
            System.out.println("Informe o animal numero " + (cont + 1));
            animais[cont] = in.nextLine();
            
            System.out.println("Informe a fruta numero " + (cont + 1));
            frutas[cont] = in.nextLine();
            
            cont++;
        } while (cont < quant);
        
        cont = 0;
        
        do {
            if (cont % 2 == 0) {
                animaisFrutas[cont] = animais[contAnimais];
                contAnimais++;
            }
            if (cont % 2 != 0) {
                animaisFrutas[cont] = frutas[contFrutas];
                contFrutas++;
            }
            cont++;
        } while (cont < (quant * 2));
        
        cont = 0;
        
        do {
            System.out.println(animaisFrutas[cont]);
            cont++;
        } while (cont < (quant * 2));
    }
    
}
