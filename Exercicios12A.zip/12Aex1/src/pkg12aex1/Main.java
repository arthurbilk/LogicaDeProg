/* 1) Faça um programa em Java com NetBeans que utiliza obrigatoriamente o laço do-while, onde o
usuário informa uma senha numérica. Previamente em seu código defina e fixe qual é a senha a ser
considerada como correta, com 4 dígitos. Compare a senha que o usuário informa com a que você
pré-determinou. Caso o usuário erre a digitação da senha, peça para digitar novamente. Use do-
while e fique pedindo a senha até o usuário acertar. Quando o usuário acertar, apresente uma
mensagem informando que a senha está correta e termine o programa. */

package pkg12aex1;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int senhaCorreta = 1903, senhaUsuario;

        do {

            System.out.println("Informe a senha de 4 digitos");
            senhaUsuario = in.nextInt();

            if (senhaUsuario == senhaCorreta) {
                System.out.println("SENHA CORRETA");
            } else {
                System.out.println("SENHA INCORRETA");
            }

        } while (senhaCorreta != senhaUsuario);

    }

}
