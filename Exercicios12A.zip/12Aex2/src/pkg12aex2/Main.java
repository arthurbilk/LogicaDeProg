/* 2) Faça um programa em Java com NetBeans que utiliza obrigatoriamente o laço do-while. O
programa deve ler repetidamente números reais. Quando for digitado o zero, interrompa a leitura de
números e apresente quantos números foram digitados e a média destes. */

package pkg12aex2;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in); 
        double media, numero, acum = 0, cont = -1;
        
        do {
            
            System.out.println("Digite um numero");
            numero = in.nextInt();
            cont++;
            acum+=numero;
            
            media = acum / cont;
            
        } while (numero != 0);
        
        System.out.println("Quant. de numeros digitados: " + cont);
        System.out.println("Media dos numeros digitados: " + media);
    }
    
}
