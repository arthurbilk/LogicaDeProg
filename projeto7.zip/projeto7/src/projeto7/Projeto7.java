
package projeto7;
import java.util.Scanner;
public class Projeto7 {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int n1, n2, acum = 0;
        
        System.out.println("Informe 2 numeros");
        n1 = in.nextInt();
        n2 = in.nextInt();
        
        while(n1 <= n2){
            if (n1%2 != 0) {
                acum+=n1;
            }
            n1++;
        }
        
        System.out.println(acum);
        
    }
    
}
