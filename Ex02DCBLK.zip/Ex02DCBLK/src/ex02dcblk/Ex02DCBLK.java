package ex02dcblk;
import java.util.Scanner;
public class Ex02DCBLK {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        double S, SR;
        
        System.out.println("Digite seu salario");
        S = teclado.nextDouble();
        
        if(S <= 800) {
            SR = S * 1.2;
        } else {
            SR = S * 1.1;
        }
        
        System.out.println("Seu novo salario é: R$" + SR);
    }

}
