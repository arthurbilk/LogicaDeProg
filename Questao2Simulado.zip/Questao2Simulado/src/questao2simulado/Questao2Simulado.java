
package questao2simulado;
import java.util.Scanner;
public class Questao2Simulado {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double eixo, carga;
        String modelo;
        
        System.out.println("Informe o modelo do seu caminhao:");
        modelo = in.nextLine();
        
        System.out.println("Informe a capacidade de carga:");
        carga = in.nextDouble();
        
        System.out.println("Informe a quantidade de eixos:");
        eixo = in.nextDouble();
        
        if (eixo == 2) {
            if (carga > 3500) {
                System.out.println("Seu " + modelo + " eh da categoria toco");
            } else {
                System.out.println("Seu " + modelo + " eh da categoria passeio");
            }
        } else if (eixo == 3) {
            if (carga > 23000) {
                System.out.println("Seu " + modelo + " eh da categoria truck");
            } else {
                System.out.println("Seu " + modelo + " eh da categoria caminhao leve");
            }
        } else if (eixo == 4) {
            if (carga > 41500) {
                System.out.println("Seu " + modelo + " eh da categoria carreta");
            } else {
                System.out.println("Seu " + modelo + " eh da categoria mini carreta");
            }
        }
    }
    
}
