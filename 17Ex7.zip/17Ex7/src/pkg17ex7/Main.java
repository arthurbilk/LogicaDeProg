/*
7) Faça um programa com vetores e matrizes, que atenda o seguinte menu descrito a
seguir. Considere como 40 alunos e 10 disciplinas a capacidade máxima do programa.
Menu:
1 – Cadastrar um nome Disciplina (vetor)
2 – Cadastrar um nome de Aluno (vetor)
3 – Cadastrar uma Média de aluno em disciplina (matriz)
4 – Listar disciplinas;
5 – Listar alunos;
6 – listar alunos e respectiva média em determinada disciplina;
0 – Sair
 */
package pkg17ex7;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String disciplina[] = new String[10];
        String aluno[] = new String[40];
        double media[][] = new double[40][10];
        int menu = 99, mediaMenu = 0, contDisciplina = 0, contAlunos = 0, numAluno, numDisciplina;

        while (menu != 0) {
            System.out.println("-------------- SIGAA IFC --------------");
            System.out.println("1 – Cadastrar uma Disciplina (" + contDisciplina + " cadastradas)");
            System.out.println("2 – Cadastrar um nome de Aluno (" + contAlunos + " cadastrados)");
            System.out.println("3 – Cadastrar uma Média de aluno em disciplina");
            System.out.println("4 – Listar disciplinas;");
            System.out.println("5 – Listar alunos;");
            System.out.println("6 – listar alunos e respectiva média em determinada disciplina;");
            System.out.println("0 – Sair");
            menu = in.nextInt();
            in.nextLine();

            switch (menu) {

                case 1:
                    if (contDisciplina == 10) {
                        System.out.println("Limite de materias excedido");
                        break;
                    } else {
                        System.out.println("Informe a disciplina N" + (contDisciplina + 1));
                        disciplina[contDisciplina] = in.nextLine();
                        contDisciplina++;
                        System.out.println("");
                        break;
                    }

                case 2:
                    if (contAlunos == 40) {
                        System.out.println("Limite de alunos excedido");
                        break;
                    } else {
                        System.out.println("Informe o aluno N" + (contAlunos + 1));
                        aluno[contAlunos] = in.nextLine();
                        contAlunos++;
                        System.out.println("");
                        break;
                    }

                case 3:
                    while (mediaMenu != 2) {
                        System.out.println(". Qual aluno?");
                        for (int i = 0; i < contAlunos; i++) {
                            System.out.println((i + 1) + " - " + aluno[i]);
                        }
                        numAluno = in.nextInt() - 1;
                        System.out.println("");

                        System.out.println(". Qual disciplina?");
                        for (int i = 0; i < contDisciplina; i++) {
                            System.out.println((i + 1) + " - " + disciplina[i]);
                        }
                        numDisciplina = in.nextInt() - 1;
                        System.out.println("");

                        System.out.println("Qual a media de " + aluno[numAluno] + " na disciplina de " + disciplina[numDisciplina] + "?");
                        media[numAluno][numDisciplina] = in.nextDouble();
                        System.out.println("");
                        
                        System.out.println("Deseja continuar cadastrando medias?");
                        System.out.println("  1. Sim");
                        System.out.println("  2. Nao");
                        mediaMenu = in.nextInt();
                        System.out.println("");
                    }
                    break;

                case 4:
                    System.out.println("----- DISCIPLINAS -----");
                    for (int i = 0; i < contDisciplina; i++) {
                        System.out.println((i + 1) + " - " + disciplina[i]);
                    }
                    System.out.println("");
                    break;

                case 5:
                    System.out.println("----- ALUNOS -----");
                    for (int i = 0; i < contAlunos; i++) {
                        System.out.println((i + 1) + " - " + aluno[i]);
                    }
                    System.out.println("");
                    break;

                case 6:
                    for (int i = 0; i < contAlunos; i++) {
                        System.out.println("Aluno: " + aluno[i]);

                        for (int j = 0; j < contDisciplina; j++) {
                            System.out.println("   . " + disciplina[j] + " - Media: " + media[i][j]);
                        }
                        System.out.println("");
                    }
                    break;

                case 0:
                    System.out.println("SISTEMA DESLIGADO");
                    break;

                default:
                    System.out.println("OPCAO INVALIDA");
            }
        }
    }

}
