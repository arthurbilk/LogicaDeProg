/*
5) Faça um programa que preencha:
- um vetor com nome de 4 lojas;
- um vetor com nome de 6 produtos;
- uma matriz com os preços de cada produto em cada loja;
Em seguida apresente uma listagem (Loja – produto) dos produtos acima de R$ 50,00.
 */
package pkg17ex5for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        String vetNomeLojas[] = new String[4];
        String vetNomeProdutos[] = new String[6];
        double matPrecos[][] = new double[vetNomeLojas.length][vetNomeProdutos.length];
        
        for (int i = 0; i < vetNomeLojas.length; i++) {
            System.out.println("Informe o nome da loja " + (i + 1));
            vetNomeLojas[i] = in.nextLine();
        }
        
        for (int i = 0; i < vetNomeProdutos.length; i++) {
            System.out.println("Informe o nome do produto " + (i + 1));
            vetNomeProdutos[i] = in.nextLine();
        }
        
        for (int linhas = 0; linhas < vetNomeLojas.length; linhas++) {
            System.out.println("Loja: " + vetNomeLojas[linhas]);
            
            for (int colunas = 0; colunas < vetNomeProdutos.length; colunas++) {
                System.out.println("    ." + vetNomeProdutos[colunas] + " - Preco: informe");
                matPrecos[linhas][colunas] = in.nextDouble();
            }
            System.out.println("================================");
        }
        
        for (int linhas = 0; linhas < vetNomeLojas.length; linhas++) {
            System.out.println("Loja: " + vetNomeLojas[linhas]);
            
            for (int colunas = 0; colunas < vetNomeProdutos.length; colunas++) {
                System.out.println("    ." + vetNomeProdutos[colunas] + " - Preco: " + matPrecos[linhas][colunas]);
            }
            System.out.println("================================");
        }
    }
}
