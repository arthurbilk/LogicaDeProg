package q06blk;

import java.util.Scanner;

public class Q06BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int n1, n2, n3;

        System.out.println("Digite 3 numeros");
        n1 = in.nextInt();
        n2 = in.nextInt();
        n3 = in.nextInt();

        if (n1 > n2) {
            if (n2 > n3) {
                System.out.println("O menor numero eh: " + n3);
            } else {
                System.out.println("O menor numero eh: " + n2);
            }
        } else if (n3 > n1) {
            System.out.println("O menor numero eh: " + n1);
        } else {
            System.out.println("O menor numero eh: " + n3);
        }

    }

}
