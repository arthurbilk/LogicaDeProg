/*
5. Crie uma sub-rotina que receba 3 notas
de um aluno como parâmetros e uma letra.
Se a letra for A, a sub-rotina deverá calcular
e retornar a média aritmética das notas do
aluno; se for P, deverá calcular e retornar a
média ponderada, como pesos, 5, 3 e 2. A
média calculada deve ser devolvida ao
programa principal e então exibida.
 */
package pkg19ex5;

import java.util.Scanner;

public class Main {
    
    static void media(double na, double nb, double nc, char opcao) {
        if (opcao == 'A' || opcao == 'a') {
            double media = na + nb + nc;
            media /= 3;
            
            System.out.println(media);
        }
        if (opcao == 'P' || opcao == 'p') {
            double media = (na * 5) + (nb * 3) + (nc * 2);
            media /= 10;
            
            System.out.println(media);
        }
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe as 3 notas do aluno");
        double n1 = in.nextDouble();
        double n2 = in.nextDouble();
        double n3 = in.nextDouble();
        
        System.out.println("Opcoes: A ou B");
        char opcao = in.next().charAt(0);
        
        media(n1, n2, n3, opcao);
    }
    
}
