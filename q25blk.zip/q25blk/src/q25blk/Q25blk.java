
package q25blk;
import java.util.Scanner;
public class Q25blk {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        String time1, time2;
        int gol1, gol2;
        
        System.out.println("Informe o nome do primeiro time");
        time1 = in.nextLine();
        
        System.out.println("Informe a quantidade gols do " + time1);
        gol1 = in.nextInt();
        
        in.nextLine();
        
        System.out.println("Informe o nome do segundo time");
        time2 = in.nextLine();
        
        System.out.println("Informe a quantidade de gols do " + time2);
        gol2 = in.nextInt();
        
        if (gol1 == gol2) {
            System.out.println("Empate");
        } else if (gol1 > gol2) {
            System.out.println(time1 + " saiu vencedor com placar de: " + gol1 + " x " + gol2);
        } else {
            System.out.println(time2 + " saiu vencedor com placar de: " + gol2 + " x " + gol1);
        }
        
    }
    
}
