package exerciciobiblioteca;

import java.util.Scanner;

public class ExercicioBiblioteca {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int numeros[] = new int[5];
        int cont = 0, soma = 0;
        
        for (int i = 0; i < 5; i++) {
            System.out.println("Digite um numero inteiro (maior que zero):");
            numeros[i] = in.nextInt();
            
            if (numeros[i] > 0) {
                soma += numeros[i];
            } else {
                System.out.println("Numero invalido.");
                i--;
            }
        }
        
        System.out.println("Soma dos positivos: " + soma);
        
        while (cont < 5) {
            System.out.println("Posicao: " + (cont + 1) + ": " + numeros[cont]);
            cont++;
        }
    }
    
}

/*
algoritmo "exemplo"

var
   numeros: vetor[1..5] de inteiro
   i, soma: inteiro

inicio

   soma <- 0

   para i de 1 ate 5 faca
      escreva("Digite um número: ")
      leia(numeros[i])

      se numeros[i] > 0 entao
         soma <- soma + numeros[i]
      senao
         escreva("Número negativo ou zero.")
      fimse
   fimpara

   escreval("Soma dos positivos: ", soma)

   i <- 1

   enquanto i <= 5 faca
      escreval("Posição ", i, ": ", numeros[i])
      i <- i + 1
   fimenquanto

fimalgoritmo
*/