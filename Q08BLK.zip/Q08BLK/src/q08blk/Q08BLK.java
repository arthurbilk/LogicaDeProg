
package q08blk;
import java.util.Scanner;
public class Q08BLK {

    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        double n1, n2, n3, media;
        
        System.out.println("Digite suas 3 notas");
        n1 = in.nextDouble();
        n2 = in.nextDouble();
        n3 = in.nextDouble();
        
        media = (n1 + n2 + n3)/3;
        
        if (media < 6) {
            System.out.println("Reprovado, sua media eh: " + media);
        } else {
            System.out.println("Aprovado, sua media eh: " + media);
        }
    }
    
}
