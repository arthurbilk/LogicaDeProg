package pkg15ex7while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int cont = 0, quant = 4, contAumento = 0, contNaoAumento = 0, posAumento = 0, posNaoAumento = 0;
        String[] nomeFuncionario = new String[quant];
        double[] salarios = new double[quant];
        int[] tempoServico = new int[quant];
        
        while (cont < quant) {            
            System.out.println("Informe o nome do funcionario N" + (cont + 1) + ":");
            nomeFuncionario[cont] = in.nextLine();

            System.out.println("Informe o salario do funcionario N" + (cont + 1) + ":");
            salarios[cont] = in.nextDouble();

            System.out.println("Informe o tempo de servico (em anos) do funcionario N" + (cont + 1) + ":");
            tempoServico[cont] = in.nextInt();
            in.nextLine();
            
            cont++;
        } 
        cont = 0;
        
        while (cont < quant) {            
            if (salarios[cont] < 1940 || tempoServico[cont] > 5) {
                contAumento++;
            } else {
                contNaoAumento++;
            }
            cont++;
        } 
        cont = 0;
        
        String[] nomeFuncionarioAumento = new String[contAumento];
        double[] salariosAumento = new double[contAumento];

        String[] nomeFuncionarioNaoAumento = new String[contNaoAumento];
        
        while (cont < quant) {            
            if (salarios[cont] < 1940 && tempoServico[cont] > 5) {
                salariosAumento[posAumento] = salarios[cont] * 1.35;
                nomeFuncionarioAumento[posAumento] = nomeFuncionario[cont];
                posAumento++;
            } else if (salarios[cont] < 1940) {
                    salariosAumento[posAumento] = salarios[cont] * 1.15;
                    nomeFuncionarioAumento[posAumento] = nomeFuncionario[cont];
                    posAumento++;
                } else if (tempoServico[cont] > 5) {
                    salariosAumento[posAumento] = salarios[cont] * 1.25;
                    nomeFuncionarioAumento[posAumento] = nomeFuncionario[cont];
                    posAumento++;
                } else {
                nomeFuncionarioNaoAumento[posNaoAumento] = nomeFuncionario[cont];
                posNaoAumento++;
            } 
            cont++;
        } 
        cont = 0;
        
        System.out.println("-----{Funcionarios sem aumento:}-----");
        while (cont < nomeFuncionarioNaoAumento.length) {            
            System.out.println("    -" + nomeFuncionarioNaoAumento[cont]);
            cont++;
        }
        
        System.out.println("-----{Funcionarios com aumento:}-----");
        while (cont < nomeFuncionarioAumento.length) {            
            System.out.println("    - Nome: " + nomeFuncionarioAumento[cont]);
            System.out.println("    - Novo salario: " + salariosAumento[cont]);
            System.out.println(" ");
            
            cont++;
        }
    }
}
