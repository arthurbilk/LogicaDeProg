/*8) Faça um programa para auxiliar um time de Futebol de campo. Deseja-se digitar as
informações de cada jogador (Nome, idade, peso e altura) e ao final obter um relatório
com:
- A quantidade de jogadores menores de idade;
- A média de idade dos atletas maiores de idade;
- A porcentagem de jogadores com mais de 80kg;
- A altura média do time;
- Os 3 jogadores mais altos;*/

package pkg14ex8dowhile;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);

        // variaveis de utilidade
        int cont = 1, menorIdade = 0, maiorIdade = 0, mais80kg = 0, quant; // conts e acums
        double mediaMaiorIdade = 0, mediaAlturaTime = 0, porcentMais80kg;

        // variaveis normais
        int idade, altura;
        double peso;
        String nome;

        // variaveis do podio
        String nomePrimeiro = "", nomeSegundo = "", nomeTerceiro = "";
        int alturaPrimeiro = 0, alturaSegundo = 0, alturaTerceiro = 0;

        System.out.println("Quantos jogadores o time tem no elenco?");
        quant = in.nextInt();
        in.nextLine();
        
        do {
            
            System.out.println("Informe o nome do " + cont + "o jogador");
            nome = in.nextLine();

            System.out.println("Informe a idade do " + cont + "o jogador");
            idade = in.nextInt();

            System.out.println("Informe a altura do " + cont + "o jogador em cm");
            altura = in.nextInt();

            System.out.println("Informe o peso do " + cont + "o jogador em kg");
            peso = in.nextDouble();

            in.nextLine();

            if (idade < 18) {
                menorIdade++;
            } else {
                maiorIdade++;
                mediaMaiorIdade += idade;
            }

            if (peso > 80) {
                mais80kg++;
            }

            mediaAlturaTime += altura;
            cont++;

            // ----------- podio ------------ //
            if (altura > alturaPrimeiro) {

                nomeTerceiro = nomeSegundo;
                alturaTerceiro = alturaSegundo;

                nomeSegundo = nomePrimeiro;
                alturaSegundo = alturaPrimeiro;

                alturaPrimeiro = altura;
                nomePrimeiro = nome;

            } else if (altura > alturaSegundo) {

                nomeTerceiro = nomeSegundo;
                alturaTerceiro = alturaSegundo;

                alturaSegundo = altura;
                nomeSegundo = nome;

            } else if (altura > alturaTerceiro) {

                alturaTerceiro = altura;
                nomeTerceiro = nome;

            }

        } while (cont <= quant);
        
        if (maiorIdade > 0) {
            mediaMaiorIdade = mediaMaiorIdade / maiorIdade;
        }
        
        porcentMais80kg = ((double) mais80kg / (double) quant) * 100;
        mediaAlturaTime = mediaAlturaTime / quant;

        System.out.println("         Informacoes sobre o time:           ");
        System.out.println("==================================================");
        System.out.println(". Jogadores menores de idade: " + menorIdade);
        if (maiorIdade > 0) {
            System.out.println(". Media de idade dos atletas maiores de idade: " + mediaMaiorIdade);
        } else {
            System.out.println(". Media de idade dos atletas maiores de idade: nao ha jogadores maiores de idade");
        }
        System.out.println(". Porcentagem de jogadores com mais de 80kg: " + porcentMais80kg);
        System.out.println(". Altura média do time: " + mediaAlturaTime);
        System.out.println(". Os maiores jogadores sao:");
        System.out.println("" + "");
        System.out.println("   -Em 3 lugar: " + nomeTerceiro + " com " + alturaTerceiro + "cm de altura");
        System.out.println("   -Em 2 lugar: " + nomeSegundo + " com " + alturaSegundo + "cm de altura");
        System.out.println("   -Em 1 lugar: " + nomePrimeiro + " com " + alturaPrimeiro + "cm de altura");

        
    }

}