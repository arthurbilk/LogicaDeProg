
package listaex5for;
import java.util.Scanner;
public class ListaEx5for {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        String nome;
        double nota, media, mediaTurma, quant = 35, acum = 0, acumNota = 0, quantNota = 1;
        
        for (int cont = 1; cont <= quant; cont++) {
            
            System.out.println("Informe seu nome");
            nome = teclado.nextLine();
            
            for (double contNota = quantNota; contNota <= 4; contNota++) {
                
                System.out.println("Informe sua nota");
                nota = teclado.nextDouble();

                acumNota += nota;

                teclado.nextLine();
                
            }
            
            media = acumNota / 4;

            System.out.println("A media de " + nome + " eh: " + media);

            acumNota = 0;
            quantNota = 1;

            acum += media;
            
        }
        
        mediaTurma = acum / quant;
        System.out.println("Media da turma: " + mediaTurma);
        
    }
    
}
