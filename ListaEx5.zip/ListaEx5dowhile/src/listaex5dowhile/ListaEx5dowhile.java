package listaex5dowhile;

import java.util.Scanner;

public class ListaEx5dowhile {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String nome;
        int cont = 1, contNota = 1;
        double nota, media, mediaTurma, quant = 35, acum = 0, acumNota = 0;

        do {

            System.out.println("Informe seu nome");
            nome = teclado.nextLine();

            do {

                System.out.println("Informe sua nota");
                nota = teclado.nextDouble();

                acumNota += nota;
                contNota++;

                teclado.nextLine();

            } while (contNota <= 4);

            media = acumNota / 4;

            System.out.println("A media de " + nome + " eh: " + media);

            acumNota = 0;
            contNota = 1;

            acum += media;

            cont++;

        } while (cont <= quant);

        mediaTurma = acum / quant;
        System.out.println("Media da turma: " + mediaTurma);

    }

}
