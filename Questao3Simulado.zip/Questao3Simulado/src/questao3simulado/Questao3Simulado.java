
package questao3simulado;
import java.util.Scanner;
public class Questao3Simulado {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int valorinicial, valor, div200, div100, div50, div10, div2, div1;
        
        System.out.println("Informe um valor inteiro em R$");
        valorinicial = in.nextInt();
        
        div200 = valorinicial / 200;
        valor = valorinicial % 200;
        
        div100 = valor / 100;
        valor = valor % 100;
        
        div50 = valor / 50;
        valor = valor % 50;
        
        div10 = valor / 10;
        valor = valor % 10;
        
        div2 = valor / 2;
        valor = valor % 2;
        
        div1 = valor / 1;
        valor = valor % 1;
        
        System.out.println(valorinicial + " decomposto eh: " + div200 + " notas de 200, " + div100 + " notas de 100, " + div50 + " notas de 50, " + div10 + " notas de 10, " + div2 + " notas de 2 e " + div1 + " moedas de 1.");
        
    }
    
}
