/*
4. Crie uma Sub-rotina que recebe 3 medidas por parâmetro e retorne se podem ser os lados de um triângulo e classifique esse triângulo.

Dica: para formar um triângulo cada lado deve ser menor que a soma dos outros dois. É necessário validar os 3 lados.
Exemplos de Testes:
1 5 9 → Não é um triângulo
9 1 5 → Não é um triângulo
1 9 5 → Não é um triângulo
3 3 3 → Equilátero
2 3 4 → Escaleno
5 6 6 → Isósceles
 */
package pkg19ex4;

import java.util.Scanner;

public class Main {
    
    static void autenticador (int la, int lb, int lc) {
        if (!(la + lb > lc && lc + lb > la && la + lc > lb)) {
            System.out.println("Triangulo falso");
        }
        if (la + lb > lc && lc + lb > la && la + lc > lb) {
            if (la == lb && lb == lc) {
                System.out.println("Triangulo equilatero");
            } else if (la == lb || la == lc || lc == lb) {
                System.out.println("Triangulo isosceles");
            } else {
                System.out.println("Triangulo escaleno");
            }
        }
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe os lados do seu triangulo: ");
        int l1 = in.nextInt();
        int l2 = in.nextInt();
        int l3 = in.nextInt();
        
        autenticador(l1, l2, l3);
    }
    
}
