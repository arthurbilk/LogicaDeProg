/* 7) Faça um programa que leia um valor inteiro e positivo, calcule e mostre o valor de E,
conforme a fórmula a seguir:
E = 1 + 10/1! + 20/2! + 30/3! +40/4! + 50/5! + ... + 10*N/N! */

package pkg14ex7while;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double N, E = 1, somaE, cont = 1, contFatorial = 1, fatorial = 1;
        
        System.out.println("Informe o termo N");
        N = in.nextDouble();
        
        while (cont <= N) {    
            
            fatorial = 1;
            contFatorial = 1;
            
            while (contFatorial <= cont) {
            
                fatorial*=contFatorial;
                contFatorial++;
                
            }
            
            somaE = (cont * 10)/fatorial;
            E += somaE;
            cont++;
        }
        
        System.out.println(E);
        
    }
    
}
