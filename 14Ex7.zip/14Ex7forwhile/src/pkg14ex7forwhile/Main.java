
package pkg14ex7forwhile;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double N, E = 1, somaE, cont = 1, contFatorial = 1, fatorial = 1;
        
        System.out.println("Informe o termo N");
        N = in.nextDouble();
        
        do {
            
            fatorial = 1;
            contFatorial = 1;
            
            do {
                
                fatorial*=contFatorial;
                contFatorial++;
                
            } while (contFatorial <= cont);
            
            somaE = (cont * 10)/fatorial;
            E += somaE;
            cont++;
            
        } while (cont <= N);
        
        System.out.println(E);
        
    }
    
}
