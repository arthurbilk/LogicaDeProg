
package pkg14ex7for;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double N, E = 1, somaE, contFatorial = 1, cont = 1, fatorial = 1;
        
        System.out.println("Informe o termo N");
        N = in.nextDouble();
        
        for (double contF = cont; contF <= N; contF++) {
            
            fatorial = 1;
            contFatorial = 1;
            
            for (double contFF = contFatorial; contFF <= contF; contFF++) {
                
                fatorial*=contFF;
                
            }
            
            somaE = (contF * 10)/fatorial;
            E += somaE;
            
        }
        
        System.out.println(E);
        
    }
    
}
