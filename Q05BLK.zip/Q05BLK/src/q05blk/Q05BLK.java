
package q05blk;
import java.util.Scanner;
public class Q05BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double N1, N2;
        
        System.out.println("Digite 2 numeros");
        N1 = in.nextDouble();
        N2 = in.nextDouble();
        
        if(N1 < N2) {
            System.out.println("Em ordem crescente: " + N1 + ", " + N2);
        } else {
            System.out.println("Em ordem crescente: " + N2 + ", " + N1);
        }
    }
    
}
