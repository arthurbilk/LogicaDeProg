/*10) Faça um programa onde o usuário digita várias cores. Ex: verde, amarelo, azul...
Determine e informe quantas vezes a cor azul foi digitada. Informe também se a cor verde
ou vermelha foi mais digitada.*/
package pkg14ex10.alt;

import java.util.Scanner;
import java.text.Normalizer;

public class Alt {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int contAzul = 0, contVerde = 0, contVermelho = 0, cont = 0;
        String cor = "", fim = "nao";

        do {

            if (cont == 0) {

                System.out.println("Digite uma cor:");
                cor = in.nextLine().toLowerCase();

            } else {

                System.out.println("Digite uma cor novamente:");
                cor = in.nextLine().toLowerCase();

            }

            switch (cor) {

                case "verde":
                    contVerde++;
                    break;

                case "azul":
                    contAzul++;
                    break;

                case "vermelho":
                    contVermelho++;
                    break;

            }
            
            System.out.println("Deseja parar?");
            fim = in.nextLine().toLowerCase();
            fim = Normalizer.normalize(fim, Normalizer.Form.NFD);

            cont++;

        } while (!fim.equals("sim"));
        
        if (contAzul == 1) {
            System.out.println("Azul foi digitado 1 vez");
        } else {
            System.out.println("Azul foi digitado " + contAzul + " vezes");
        }
        
        if (contVerde == contVermelho) {
            System.out.println("Verde e vermelho foram digitados igualmente");
        } else if (contVerde > contVermelho) {
            System.out.println("Verde foi mais digitado que vermelho");
        } else {
            System.out.println("Vermelho foi mais digitado que verde");
        }
        
        if (cont == 1) {
            System.out.println("1 cor foi digitada");
        } else {
            System.out.println(cont + " cores foram digitadas");
        }

    }

}
