
/*
4) Informe o fatorial de um informado pelo usuário.
Fatorial é o resultado da multiplicação dos números inteiros entre 1 e o próprio número
informado.
Exemplo: 5! (lemos cinco fatorial) é o resultado de 1*2*3*4*5
 */
package pkg14ex4while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int numero, cont = 1, fatorial = 1;
        
        System.out.println("Informe um numero");
        numero = in.nextInt();
        
        while( cont <= numero ){
            fatorial *= cont;
            cont++;
        }
        System.out.println("A fatorial de " + numero + " é igual " + fatorial);
    }

}
