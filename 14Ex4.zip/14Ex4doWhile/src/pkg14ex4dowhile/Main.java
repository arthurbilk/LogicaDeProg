package pkg14ex4dowhile;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int numero, cont = 1, fatorial = 1;

        System.out.println("Informe um numero");
        numero = in.nextInt();
        
        do {
            
            fatorial *= cont;
            cont++;
        
        } while (cont <= numero);
        System.out.println("A fatorial de " + numero + " é igual " + fatorial);

    }

}
