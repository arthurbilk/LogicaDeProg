package pkg14ex4for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int numero, fatorial = 1;

        System.out.println("Informe um numero");
        numero = in.nextInt();

        for (int cont = 1; cont <= numero; cont++) {

            fatorial *= cont;

        }
        
        System.out.println("A fatorial de " + numero + " é igual " + fatorial);

    }

}
