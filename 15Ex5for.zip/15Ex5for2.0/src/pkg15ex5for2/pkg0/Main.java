
package pkg15ex5for2.pkg0;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int tamanhoVet1 = 100, tamanhoVet2 = 5;
        int vet1[] = new int[tamanhoVet1];
        int vet2[] = new int[tamanhoVet2];
        
        for (int i = 0; i < tamanhoVet1; i++) {
            int numeroAleatorio = (int) (Math.random() * 101);
            vet1[i] = numeroAleatorio;
        }
        
        for (int i = 0; i < tamanhoVet2; i++) {
            System.out.println("Digite o " + (i + 1) + "° numero:");
            vet2[i] = in.nextInt();
        }
        
        System.out.println("-----Numeros encontrados-----");
        
        for (int i = 0; i < tamanhoVet2; i++) {
            boolean encontrou = false;
            
            for (int j = 0; j < tamanhoVet1; j++) {
                
                if (vet2[i] == vet1[j]) {
                    System.out.println("Numero: " + vet2[i] + " - Posicao: " + j);
                }
                
                encontrou = true;
            }
            
            if (!encontrou) {
                System.out.println("Numero: " + vet2[i] + " - Posicao: NAO ENCONTRADO");
            }
            
        }
        
    }
    
}
