package q16blk;

import java.util.Scanner;

public class Q16BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        double quant, valor;
        int cod;

        System.out.println("Informe o codigo e a quantidade comprada de um produto");
        cod = in.nextInt();
        quant = in.nextDouble();

        switch (cod) {

            case 5:
                valor = quant * 32;
                break;

            case 6:
                valor = quant * 45;
                break;

            case 2:
                valor = quant * 37;
                break;

            case 12:
                valor = quant * 44;
                break;

            default:
                System.out.println("Codigo invalido");
                valor = 0;
        }

        System.out.println("O valor devido eh: R$" + valor);

    }

}
