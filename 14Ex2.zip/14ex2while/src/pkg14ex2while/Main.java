
package pkg14ex2while;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int exp = 0, expUser, numSequencia;
        
        System.out.println("Informe um expoente");
        expUser = in.nextInt();
        
        while(exp < expUser) {
            
            numSequencia = Math.powExact(2, exp);
            System.out.println(numSequencia);
            exp++;
            
        }
        
    }
    
}
