package pkg14ex2dowhile;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int exp = 0, expUser, numSequencia;

        System.out.println("Informe um expoente");
        expUser = in.nextInt();

        do {

            numSequencia = Math.powExact(2, exp);
            System.out.println(numSequencia);
            exp++;

        } while (exp < expUser);

    }

}
