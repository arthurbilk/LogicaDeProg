
package pkg14ex2for;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int expUser, numSequencia;
        
        System.out.println("Informe um expoente");
        expUser = in.nextInt();
        
        for (int exp = 0; exp < expUser; exp++) {
            
            numSequencia = Math.powExact(2, exp);
            System.out.println(numSequencia);
            
        }
        
    }
    
}
