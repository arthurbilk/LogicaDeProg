package ex01blk;

import java.util.Scanner;

public class Ex01BLK {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        float Cel, Fah;

        System.out.println("Digite uma temperatura em celsius");
        Cel = teclado.nextFloat();

        Fah = (9 * Cel + 160) / 5;

        System.out.println("A temperatura em fahrenheit é " + Fah);
    }

}
