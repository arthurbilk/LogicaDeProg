package q01blk;
import java.util.Scanner;
public class Q01BLK {

    public static void main(String[] args) {
        
        Scanner t = new Scanner(System.in);
        int N;
        
        System.out.println("Digite um numero");
        N = t.nextInt();
        
        if(N%2 == 0) {
            System.out.println(N + " eh par");
        } else {
            System.out.println(N + " eh impar");
        }
    }

}
