
package q23blk;
import java.util.Scanner;
public class Q23BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int cmc, fim, tempo;
        
        System.out.println("Insira a hora de inicio e a de fim do jogo");
        cmc = in.nextInt();
        fim = in.nextInt();
        
        if (cmc > fim) {
            fim = fim + 24;
            tempo = fim - cmc;
        } else {
            tempo = fim - cmc;
        }
        
        System.out.println("A duracao do jogo foi de " + tempo + " hora(s)");
        
    }
    
}
