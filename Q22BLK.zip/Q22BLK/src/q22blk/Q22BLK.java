package q22blk;

import java.util.Scanner;

public class Q22BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int i;
        double a, b, c;

        System.out.println("Informe o valor de i");
        i = in.nextInt();

        System.out.println("Insira o valor de a, b e c");
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        switch (i) {

            case 1:
                if (a > b) {
                    if (b > c) {
                        System.out.println("De maneira crescente: " + c + ", " + b + ", " + a);
                    } else if (c > a) {
                        System.out.println("De maneira crescente: " + b + ", " + a + ", " + c);
                    } else {
                        System.out.println("De maneira crescente: " + b + ", " + c + ", " + a);
                    }
                } else if (c > a) {
                    if (c > b) {
                        System.out.println("De maneira crescente: " + a + ", " + b + ", " + c);
                    } else {
                        System.out.println("De maneira crescente: " + a + ", " + c + ", " + b);
                    }
                } else {
                    System.out.println("De maneira crescente: " + c + ", " + a + ", " + b);
                }
                break;

            case 2:
                if (a > b) {
                    if (b > c) {
                        System.out.println("De maneira decrescente: " + a + ", " + b + ", " + c);
                    } else if (c > a) {
                        System.out.println("De maneira decrescente: " + c + ", " + a + ", " + b);
                    } else {
                        System.out.println("De maneira decrescente: " + a + ", " + c + ", " + b);
                    }
                } else if (c > a) {
                    if (c > b) {
                        System.out.println("De maneira decrescente: " + c + ", " + b + ", " + a);
                    } else {
                        System.out.println("De maneira decrescente: " + b + ", " + c + ", " + a);
                    }
                } else {
                    System.out.println("De maneira decrescente: " + b + ", " + a + ", " + c);
                }
                break;

            case 3:
                if (a > b) {
                    if (b > c) {
                        System.out.println("De maneira com que o maior entre os dois fique no meio: " + c + ", " + a + ", " + b);
                    } else if (c > a) {
                        System.out.println("De maneira com que o maior entre os dois fique no meio: " + b + ", " + c + ", " + a);
                    } else {
                        System.out.println("De maneira com que o maior entre os dois fique no meio: " + b + ", " + a + ", " + c);
                    }
                } else if (c > a) {
                    if (c > b) {
                        System.out.println("De maneira com que o maior entre os dois fique no meio: " + a + ", " + c + ", " + b);
                    } else {
                        System.out.println("De maneira com que o maior entre os dois fique no meio: " + a + ", " + b + ", " + c);
                    }
                } else {
                    System.out.println("De maneira com que o maior entre os dois fique no meio: " + c + ", " + b + ", " + a);
                }
                break;

            default:
                System.out.println("ERRO: insira um codigo valido");
        }

    }

}
