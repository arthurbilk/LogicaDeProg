package listaex4;

import java.util.Scanner;

public class ListaEx4 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int positivo = 0, negativo = 0, zero = 0, cont = 1, num;

        do {

            System.out.println("Informe um numero");
            num = teclado.nextInt();

            if (num > 0) {
                positivo++;
            }

            if (num == 0) {
                zero++;
            }

            if (num < 0) {
                negativo++;
            }

            cont++;

        } while (cont <= 10);

        System.out.println("Foram digitados:");
        
        if (positivo == 1) {
            System.out.println("-" + positivo + " positivo");
        } else {
            System.out.println("-" + positivo + " positivos");
        }
        
        if (negativo == 1) {
            System.out.println("-" + negativo + " negativo");
        } else {
            System.out.println("-" + negativo + " negativos");
        }
        
        if (zero == 1) {
            System.out.println("-" + zero + " zero");
        } else {
            System.out.println("-" + zero + " zeros");
        }
        
    }

}
