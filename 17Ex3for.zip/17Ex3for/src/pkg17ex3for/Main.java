/*
3) Crie um programa com duas matrizes matriz 2x2. Uma é preenchida pelo usuário.
Depois de preenchida encontre o maior elemento. Na segunda matriz armazene o
resultado da multiplicação de cada elemento da primeira matriz pelo maior elemento.
Apresente a matriz resultante.
 */
package pkg17ex3for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int tamanho = 2, maior;
        int matNum[][] = new int[tamanho][tamanho];
        int matMult[][] = new int[tamanho][tamanho];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.println("Informe um valor para a posicao[" + linha + "][" + coluna + "]:");
                matNum[linha][coluna] = in.nextInt();
            }
        }
        
        maior = matNum[0][0];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                if (matNum[linha][coluna] > maior) {
                    maior = matNum[linha][coluna];
                }
            }
        }
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                matMult[linha][coluna] = maior * matNum[linha][coluna];
            }
        }
        
        for (int linha = 0; linha < tamanho; linha++) {
            System.out.println(" ");
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.print(matMult[linha][coluna] + " ");
            }
        }
    }
    
}
