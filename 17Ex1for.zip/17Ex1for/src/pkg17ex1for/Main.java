/*
1) Crie um programa com uma matriz 5x5, que é preenchida pelo usuário e em seguida a
apresente na tela.
 */
package pkg17ex1for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int tamanho = 5;
        String matrizNome[][] = new String[tamanho][tamanho];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.println("Informe um nome");
                matrizNome[linha][coluna] = in.nextLine();
            }
        }
        
        for (int linha = 0; linha < tamanho; linha++) {
            System.out.println("");
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.print(matrizNome[linha][coluna] + " ");
            }
        }
    }
    
}
