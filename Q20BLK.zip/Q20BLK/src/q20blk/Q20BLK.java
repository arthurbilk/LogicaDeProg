package q20blk;

import java.util.Scanner;

public class Q20BLK {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int div100, div50, div10, div5, div1, valor, vlant;

        System.out.println("Insira um valor em R$");
        vlant = in.nextInt();

        div100 = vlant / 100;
        valor = vlant % 100;

        div50 = valor / 50;
        valor = valor % 50;

        div10 = valor / 10;
        valor = valor % 10;

        div5 = valor / 5;
        valor = valor % 5;

        div1 = valor / 1;
        valor = valor % 1;

        System.out.println(vlant + "decomposto eh: " + div100 + " notas de 100, " + div50 + " notas de 50, " + div10 + " notas de 10, " + div5 + " notas de 5 e " + div1 + " moedas de 1. A sobra eh: " + valor);
         
    }
    
}
