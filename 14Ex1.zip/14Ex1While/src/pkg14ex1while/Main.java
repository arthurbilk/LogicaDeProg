package pkg14ex1while;

public class Main {

    public static void main(String[] args) {

        int mult = 0, resultado, cont = 0;

        while (mult < 11) {
            while (cont < 11) {

                resultado = cont * mult;
                System.out.println(mult + " x " + cont + " = " + resultado);
                cont++;

            }

            System.out.println("=========");
            mult++;
            cont = 0;
        }

    }

}
