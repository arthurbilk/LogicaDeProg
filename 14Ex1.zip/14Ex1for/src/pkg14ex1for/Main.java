
package pkg14ex1for;

public class Main {

    public static void main(String[] args) {
        
        int resultado;
        
        for (int mult = 0; mult < 11; mult++) {
            for (int cont = 0; cont < 11; cont++) {
                
                resultado = cont * mult;
                System.out.println(mult + " x " + cont + " = " + resultado);
                
            }
            
            System.out.println("=========================");
            
        }
        
    }
    
}
