package pkg14ex1dowhile;

public class Main {

    public static void main(String[] args) {

        int resultado, cont = 0, mult = 0;

        do {
            do {

                resultado = mult * cont;
                System.out.println(mult + " x " + cont + " = " + resultado);
                cont++;

            } while (cont < 11);

            System.out.println("=====================");
            mult++;
            cont = 0;

        } while (mult < 11);

    }

}
