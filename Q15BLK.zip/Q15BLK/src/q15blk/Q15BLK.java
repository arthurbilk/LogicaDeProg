
package q15blk;
import java.util.Scanner;
public class Q15BLK {

    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        double vc, saldo;
        
        System.out.println("Informe seu saldo");
        saldo = in.nextDouble();
        
        if (201 > saldo) {
            System.out.println("Sem credito");
            vc = 0;
        } else if (401 > saldo) {
            vc = saldo * 0.2;
        } else if (601 > saldo) {
            vc = saldo * 0.3;
        } else {
            vc = saldo * 0.4;
        }
        
        System.out.println("Seu saldo eh: " + saldo + ", logo seu credito eh: " + vc);
        
    }
    
}
