
package q11blk;
import java.util.Scanner;
public class Q11BLK {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        double mn, n2, n3, media;
        
        System.out.println("Informe sua maior nota");
        mn = in.nextDouble();
        
        System.out.println("Informe suas notas restantes");
        n2 = in.nextDouble();
        n3 = in.nextDouble();
        
        media = ((mn * 4) + (n2 * 3) + (n3 * 3))/10;
        
        if (media < 6) {
            System.out.println("Notas: " + mn + ", " + n2 + ", " + n3);
            System.out.println("Media: " + media + ". Reprovado");
        } else {
            System.out.println("Notas: " + mn + ", " + n2 + ", " + n3);
            System.out.println("Media: " + media + ". Aprovado");
        }
    }
    
}
