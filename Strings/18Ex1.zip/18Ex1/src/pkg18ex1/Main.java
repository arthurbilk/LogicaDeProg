/*
1 – Crie um programa que informa a quantidade de caracteres de uma frase informada
pelo usuário;
 */
package pkg18ex1;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Informe uma frase");
        String frase = in.nextLine();
        
        int tamanho = frase.length();
        
        System.out.println("O tamanho da sua frase eh de " + tamanho + " caracteres");
    }
    
}
