/*
6 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresente o sobre-nome seguido de vírgula e os demais nomes.
Exemplo: Paulo Eduardo Marcondes Silva → Silva, Paulo Eduardo Marcondes
 */
package pkg18ex6;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String nome;
        
        System.out.println("Informe seu nome completo:");
        nome = in.nextLine();
        
        String[] vetNome = nome.split(" ");
        
        System.out.print(vetNome[vetNome.length - 1] + ",");
        for (int i = 0; i < vetNome.length - 1; i++) {
            System.out.print(" " + vetNome[i]);
        }
    }
    
}
