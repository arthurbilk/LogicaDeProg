package pkg18ex7alt;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String nomeCompleto;
        int cont = 0;
        char nomeMeio = ' ';
        
        System.out.println("Informe seu nome completo:");
        nomeCompleto = in.nextLine();
        
        String[] vetNome = nomeCompleto.split(" ");
        String nome = vetNome[0];
        String sobrenome = vetNome[vetNome.length - 1];
        
        String nomeAbreviado = nome;
        
        for (int i = 1; i < vetNome.length - 1; i++) {
            if (vetNome[i].equalsIgnoreCase("de")
            || vetNome[i].equalsIgnoreCase("da")
            || vetNome[i].equalsIgnoreCase("das")
            || vetNome[i].equalsIgnoreCase("do")
            || vetNome[i].equalsIgnoreCase("dos")) {
                nomeAbreviado += " " + vetNome[i];
            } else {
                nomeAbreviado += " " + vetNome[i].charAt(0) + ".";
            }
        }
        
        nomeAbreviado += " " + sobrenome;
        
        System.out.println(nomeAbreviado);
        
    }
    
}
