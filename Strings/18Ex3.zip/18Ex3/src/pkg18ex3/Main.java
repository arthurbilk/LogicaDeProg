/*
3 - Crie um programa que informa a quantidade de palavras de uma frase informada pelo
usuário;
 */
package pkg18ex3;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String espaco = " ";
        int cont = 1;
        
        System.out.println("Informe uma frase");
        String frase = in.nextLine().toLowerCase();
        
        for (int i = 0; i < frase.length(); i++) {
            char comparacao = frase.charAt(i);
            
            if (String.valueOf(comparacao).equals(espaco)) {
                cont++;
            }
        }
        
        System.out.println("Sua frase tem " + cont + " palavras");
    }
    
}
