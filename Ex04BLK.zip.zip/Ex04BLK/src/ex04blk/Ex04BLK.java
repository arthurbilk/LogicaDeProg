package ex04blk;
import java.util.Scanner;
public class Ex04BLK {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int A, B, reserva;
        
        System.out.println("Digite um valor para a variavel A");
        A = teclado.nextInt();
        
        System.out.println("Digite um valor para a variavel B");
        B = teclado.nextInt();
        
        reserva = A;
        A = B;
        B = reserva;
        
        System.out.println("O valor de A e B é respectivamente: " + A + " e " + B);
    }
    
}
