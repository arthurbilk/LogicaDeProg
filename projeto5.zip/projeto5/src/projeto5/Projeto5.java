package projeto5;

public class Projeto5 {

    public static void main(String[] args) {

        int cont = 100;

        while (cont <= 200) {
            
            if (cont % 3 == 0 && cont % 5 == 0) {
                System.out.println(cont);
            }
            
            cont = cont + 1;
        }

    }

}
