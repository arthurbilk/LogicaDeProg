
package q18blk;
import java.util.Scanner;
public class Q18BLK {

    public static void main(String[] args) {
       
        Scanner in = new Scanner(System.in);
        int cod;
        double salant, salnov, dif;
        
        System.out.println("Informe seu salario e o codigo do seu cargo");
        salant = in.nextDouble();
        cod = in.nextInt();
        
        switch (cod) {
            
            case 101:
                salnov = salant * 1.1;
                break;
                
            case 102:
                salnov = salant * 1.2;
                break;
                
            case 103:
                salnov = salant * 1.3;
                break;
                
            default:
                salnov = salant * 1.4;
        }
        
        dif = salnov - salant;
        
        System.out.println("Salario antigo: R$" + salant);
        System.out.println("Salario novo: R$" + salnov);
        System.out.println("Diferenca: R$" + dif);
        
    }
    
}
