/*2. Preencha com números um vetor com 10
posições. Depois apresente uma listagem com os
números superiores a 50. O programa deverá mostrar
uma mensagem se não existir nenhum.*/

package pkg15ex2for;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int quant = 10, cont50 = 0;
        int vetNum[] = new int[quant];

        // for pra preenchimento de vetor
        for (int cont = 0; cont < quant; cont++) {
            System.out.println("Informe o numero " + (cont + 1) + ":");
            vetNum[cont] = in.nextInt();
        }

        // for pra saida
        System.out.println("Numeros digitados maiores que 50:");
        for (int cont = 0; cont < quant; cont++) {
            if (vetNum[cont] > 50) {
                System.out.println("." + vetNum[cont]);
                cont50++;
            }
        }
        
        if (cont50 == 0) {
            System.out.println(". Nenhum numero maior que 50");
        }
    }
}