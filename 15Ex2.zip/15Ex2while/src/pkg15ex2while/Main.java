/*2. Preencha com números um vetor com 10
posições. Depois apresente uma listagem com os
números superiores a 50. O programa deverá mostrar
uma mensagem se não existir nenhum.*/

package pkg15ex2while;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int cont50 = 0, cont = 0, quant = 10;
        int vetNum[] = new int[quant];
        
        // entrada
        while (cont < quant) {            
            System.out.println("Informe o numero " + (cont + 1) + ":");
            vetNum[cont] = in.nextInt();
            cont++;
        }
        
        cont = 0;
        
        // saida
        System.out.println("Numeros digitados maiores que 50:");
        while (cont < quant) {            
            if (vetNum[cont] > 50) {
                System.out.println(". " + vetNum[cont]);
                cont50++;
            }
            cont++;
        }
        
        if (cont50 == 0) {
            System.out.println("   . Nenhum numero maior que 50");
        }
    }
    
}
